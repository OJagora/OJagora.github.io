#!/usr/bin/env python3
"""Render the editable Markdown report and one-page findings brief to PDF.

Usage: python render_report.py
Requires reportlab, pillow. Supports the Markdown structures used in this package.
Keep all figures available in figures/. Uses embedded DejaVu fonts when installed.
"""
from pathlib import Path
import re,html
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle,Image,KeepTogether
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from PIL import Image as PILImage

BASE=Path(__file__).resolve().parent
FONTDIR=Path('/usr/share/fonts/truetype/dejavu')
if FONTDIR.exists():
 for name,file in [('Research','DejaVuSans.ttf'),('Research-Bold','DejaVuSans-Bold.ttf'),('Research-Italic','DejaVuSans-Oblique.ttf')]:
  path=FONTDIR/file
  if not path.exists():path=FONTDIR/'DejaVuSans.ttf'
  pdfmetrics.registerFont(TTFont(name,str(path)))
 pdfmetrics.registerFontFamily('Research',normal='Research',bold='Research-Bold',italic='Research-Italic',boldItalic='Research-Bold')
 FONT='Research'
else:FONT='Helvetica'
BLUE=colors.HexColor('#194E7A');GRAY=colors.HexColor('#5B6875');LIGHT=colors.HexColor('#EDF3F7')

def markup(s):
 # Escape first, then introduce only the formatting used by our Markdown.
 s=html.escape(s)
 s=re.sub(r'\[([^\]]+)\]\((https?://[^\)]+)\)',lambda m:f'<a href="{m[2]}" color="#2364A2">{m[1]}</a>',s)
 s=re.sub(r'\*\*([^*]+)\*\*',r'<b>\1</b>',s)
 s=re.sub(r'`([^`]+)`',r'<font name="Courier">\1</font>',s)
 return s

def render(md,pdf,brief=False):
 w,h=A4; margin=39 if brief else 46
 doc=SimpleDocTemplate(str(pdf),pagesize=A4,rightMargin=margin,leftMargin=margin,topMargin=39 if brief else 45,bottomMargin=35 if brief else 43,
  title='Quantifying the AI Access Gap' if not brief else 'AI Access Gap: Findings Brief',author='Research prepared for Octave Jagora')
 avail=w-2*margin
 size=9.2 if brief else 9.65;leading=12.4 if brief else 14
 styles={
  'body':ParagraphStyle('Body',fontName=FONT,fontSize=size,leading=leading,textColor=colors.HexColor('#202B35'),spaceAfter=6 if brief else 8),
  'h1':ParagraphStyle('Title',fontName=FONT+'-Bold' if FONT=='Research' else 'Helvetica-Bold',fontSize=22 if brief else 27,leading=27 if brief else 32,textColor=BLUE,spaceAfter=10,keepWithNext=True),
  'h2':ParagraphStyle('H2',fontName=FONT+'-Bold' if FONT=='Research' else 'Helvetica-Bold',fontSize=11 if brief else 15,leading=14 if brief else 19,textColor=BLUE,spaceBefore=11 if brief else 16,spaceAfter=6,keepWithNext=True),
  'h3':ParagraphStyle('H3',fontName=FONT+'-Bold' if FONT=='Research' else 'Helvetica-Bold',fontSize=10.5 if brief else 11.8,leading=14 if brief else 16,textColor=BLUE,spaceBefore=9,spaceAfter=5,keepWithNext=True),
  'table':ParagraphStyle('Cell',fontName=FONT,fontSize=7.35 if brief else 7.9,leading=9.6 if brief else 10.8,spaceAfter=0),
  'caption':ParagraphStyle('Caption',fontName=FONT,fontSize=8,leading=11,textColor=GRAY,spaceAfter=10),
  'quote':ParagraphStyle('Quote',fontName=FONT,fontSize=size,leading=leading,textColor=BLUE,leftIndent=13,rightIndent=7,spaceBefore=5,spaceAfter=10),
 }
 text=md.read_text();lines=text.splitlines();story=[];i=0
 while i<len(lines):
  line=lines[i].strip()
  if not line:i+=1;continue
  if line.startswith('|'):
   table=[]
   while i<len(lines) and lines[i].strip().startswith('|'):
    cells=[x.strip() for x in lines[i].strip().strip('|').split('|')]
    if not all(re.fullmatch(r':?-+:?',c.replace(' ','')) for c in cells):table.append(cells)
    i+=1
   n=len(table[0]);widths=[avail/n]*n
   if n==3:widths=[avail*.33,avail*.28,avail*.39]
   if n==4:widths=[avail*.25]*4
   if n==6:widths=[avail*.29,avail*.10,avail*.14,avail*.14,avail*.13,avail*.20]
   data=[[Paragraph(markup(c),styles['table']) for c in row] for row in table]
   t=Table(data,colWidths=widths,repeatRows=1,hAlign='LEFT')
   t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),LIGHT),('VALIGN',(0,0),(-1,-1),'TOP'),
    ('LINEBELOW',(0,0),(-1,0),.8,BLUE),('LINEBELOW',(0,1),(-1,-1),.3,colors.HexColor('#D5DEE5')),
    ('LEFTPADDING',(0,0),(-1,-1),6),('RIGHTPADDING',(0,0),(-1,-1),6),
    ('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),6)]))
   story.extend([t,Spacer(1,9)]);continue
  m=re.match(r'!\[([^\]]*)\]\(([^)]+)\)',line)
  if m:
   p=BASE/m[2]
   with PILImage.open(p) as im:iw,ih=im.size
   img=Image(str(p),width=avail,height=avail*ih/iw)
   # Image and following figure caption stay together.
   j=i+1
   while j<len(lines) and not lines[j].strip():j+=1
   if j<len(lines) and lines[j].startswith('**Figure'):
    cap=Paragraph(markup(lines[j]),styles['caption'])
    block=[img,Spacer(1,4),cap]
    if story and isinstance(story[-1],Paragraph) and story[-1].style.name in ['H2','H3']:
     block.insert(0,story.pop())
    story.append(KeepTogether(block));i=j+1
   else:story.extend([img,Spacer(1,8)]);i+=1
   continue
  if line.startswith('#'):
   n=len(line)-len(line.lstrip('#'));key='h1' if n==1 else 'h2' if n==2 else 'h3'
   story.append(Paragraph(markup(line[n:].strip()),styles[key]));i+=1;continue
  if line.startswith('>'):
   para=line.lstrip('> ').strip();story.append(Paragraph(markup(para),styles['quote']));i+=1;continue
  if line.startswith('- '):
   story.append(Paragraph('• '+markup(line[2:]),styles['body']));i+=1;continue
  # Join paragraph lines only, never join table/heading/image blocks.
  para=[line];i+=1
  while i<len(lines) and lines[i].strip() and not lines[i].lstrip().startswith(('#','|','![','>','- ')):
   para.append(lines[i].strip());i+=1
  story.append(Paragraph(markup(' '.join(para)),styles['body']))
 def page(canvas,doc):
  canvas.saveState();canvas.setStrokeColor(colors.HexColor('#D6E0E8'));canvas.line(margin,26,w-margin,26)
  canvas.setFont(FONT,7);canvas.setFillColor(GRAY)
  canvas.drawString(margin,15,'AI ACCESS GAP  •  EVIDENCE CUTOFF 13 OCTOBER 2026')
  canvas.drawRightString(w-margin,15,str(doc.page));canvas.restoreState()
 doc.build(story,onFirstPage=page,onLaterPages=page)

if __name__=='__main__':
 render(BASE/'research_report.md',BASE/'research_report.pdf')
 render(BASE/'findings_summary.md',BASE/'findings_summary.pdf',brief=True)
 print('Rendered research_report.pdf and findings_summary.pdf')
