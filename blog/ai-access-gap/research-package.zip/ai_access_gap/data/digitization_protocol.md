# Codex Figure 10 digitization

Source: Johnston et al., The Shift to Agentic AI: Evidence from Codex, arXiv:2606.26959v1, PDF page 19 (zero-based page 18), Figure 10.

The three panels are raster images embedded at 1440 x 1020 pixels. They were extracted from the original PDF, inspected visually, and checked against plotted gridlines. Their PDF placement identifies the panels: top-left OpenAI; top-right organizational; bottom-center individual. The population is daily active Codex accounts. Endpoint is June 11, 2026.

Calibration in the extracted panels:

| Panel | Zero-hour gridline y | Grid reference | Approximate pixels/hour |
| --- | --- | --- | --- |
| OpenAI | 816.5 | 80h at y~107 | 8.87 |
| Organizational | 816.5 | 20h at y~202 | 30.73 |
| Individual | 816.5 | 20h at y~164 | 32.62 |

Line endpoints lie near x=991-994. Thick/diagonal strokes make a single-column pixel-center interpretation unstable, especially at P99. Readings were rounded conservatively rather than given spurious image-derived precision. OpenAI P50=2.5h and P99~71h use printed text anchors; P90~17.5h is a visual reading. External readings are approximately org 0.42/2.45/12.4h and individual 0.55/3.1/15.5h for P50/P90/P99.

`runtime_percentiles.csv` records conservative interpretation intervals. These encompass line thickness and endpoint-reading variation; they are not probabilistic confidence intervals. A ratio interval is formed as numerator_lower/denominator_upper to numerator_upper/denominator_lower. The population/day and runtime definitions are unchanged from the paper. Median agent-hours are never converted to GPU-hours.

The original raster panels are reproducible by extracting the three images from page 19 using PyMuPDF (`page.get_images()`, `pdf.extract_image(xref)`). They are not redistributed as separate publication figures. The new comparison figure uses only the attributed approximate endpoint values.
