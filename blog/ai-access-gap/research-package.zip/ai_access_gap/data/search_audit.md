# Search audit and stopping criteria

## Extended search after the first completed version

Additional query families used October 13: token consumption per developer/user/day, ChatGPT daily input/output telemetry, tokenmaxxing distributions, Jellyfish and Viberank primary data, educational token logs and carbon-feedback studies, internal Meta employee tokens and budgets, and independent agent trace/log-audit datasets. Engine 2 located the main additional sources; engine 1 was used for primary/current gap checks and original reporting. Full author-posted student PDF and primary Jellyfish tables, Viberank API, healthcare paper and enterprise page were reviewed. The expanded ledger adds S34-S45.

Viberank's June report and current API represent different cohorts/windows. The API snapshot was frozen at its own generation timestamp. Its global activeDays field does not mean summed active person-days. The student paper's Figure 5 shows July 8-24 inclusive; reconstructed sums use that 17-calendar-day denominator rather than treating per-day mean token lengths as consumption totals. A source-specific per-prompt CI is recorded without transferring it to a daily ratio.

The large Brookings education report's token chart was investigated as a possible consumer measurement. Its provenance points to OpenRouter provider usage. OpenRouter's primary provider page labels the metric 'Tokens processed on OpenRouter'; it is not consumer ChatGPT-wide telemetry and does not share OpenAI's weekly-active-user denominator. It is excluded from consumer per-user normalization. AgentX's primary dataset card was reviewed; full trace archives are unnecessary for person-day analysis because its schema lacks the needed user and absolute-day attribution. Secondary reporting of subscription maxima could not be tied to a reproducible original limit test and was not promoted to an observed cap.

Stopping criterion for this extension: the new numerical distributions and matched-aggregate reconstructions have been extracted; additional searches returned proxy traffic, guessed workloads, anecdotes or datasets lacking person-day attribution. Absence of a representative casual ledger remains an identified evidence gap, not proof that one cannot exist.

Research performed October 13, 2026. This was a structured primary-source investigation, not a preregistered systematic review. Both available search engines were used; routine queries used engine 2, with engine 1 used for initial/current-source verification and gap checking. Some engine-1 batches returned poor matches; successful follow-up queries and direct primary retrieval resolved the main sources.

Query families included:

- Karpathy October 11/12 AI funnel, full wording, X status ID and edited-post metadata.
- OpenAI researcher daily inference expenditure, median/P90 and methods; Codex runtime, tokens, concurrency, output growth and internal/external accounts.
- ChatGPT consumer messages per user and weekly/daily active definitions; full consumer and enterprise papers.
- Anthropic internal work transformation; Claude Code average developer cost, historical $6/$12 references versus current $13/$30; external expertise, autonomy and Economic Index data releases.
- Google/DeepMind internal tokens, developer tooling and per-employee consumption; Meta AI and xAI internal employee inference.
- Copilot prompts/actions per day, production coding-agent traces, public schema/release card, external token statistics and cache reuse.
- Cursor usage intensity, token/spend concentration, context growth, public pricing and agent behavior.
- AI spending per employee, Ramp transaction benchmarks and one-operator external cases.
- Public model-specific API rates, consumer usage limits, context windows, inference-price histories, active/total parameters and production energy measurement.

Priority inclusion: actual usage telemetry or quantitative primary disclosures with a stated numerator, interpretable scope and a usable denominator. Secondary stories were used as locators, not as substitutes for primary numerical evidence. Self-reports and executive aggregates are labeled separately. Capacity documentation is recorded as capacity rather than consumption.

Main extraction routes: full papers/PDF appendices; direct HTML; hidden primary-method text and embedded Vega-Lite numeric chart data; accessible Cursor numerical tables; primary X HTML/syndication publication metadata; official public dataset cards.

Not completed or unavailable: full original/edited Karpathy long-post text from primary endpoints; proprietary employee person-day ledgers; complete raw Claude Economic Index file-level audit; public Copilot archives (about 3GB, omit user IDs); an independently audited personal subscription/API panel; matched historical 2023-2026 cross-population physical-compute series. The Economic Index dataset viewer displayed an error; the repository card and June release listing were accessible, but this is not presented as an exhaustive schema audit.

No usable per-researcher distribution was found for Google, Meta or xAI. Google organization-wide tokens were retained. This finding describes this search, not proof that all other data are absent. We stopped expanding search when additional sources mostly supplied organizational totals, productivity, per-turn metrics or adoption shares rather than the missing matched person-day ledger. Missing quantities remain visible.
