#!/usr/bin/env python3
"""Reproduce AI-access-gap comparisons, scenario tables and publication figures.

Usage: python analysis.py [--output PATH]
Dependencies: pandas, numpy, matplotlib. No network, credentials or raw user data.

Inputs are the frozen evidence CSV and numerical chart/table snapshots in data/.
Original reported values remain immutable. This script writes separate normalized
and derived tables. A scenario interval is NEVER labeled a confidence interval.
Agent runtime is NEVER converted into GPU-hours. Reasoning is added to output
only in scenarios where visible and reasoning quantities are disjoint.
"""
from pathlib import Path
import argparse,json,math,hashlib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

BASE=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=BASE);args=ap.parse_args()
OUT=args.output;OUT.mkdir(parents=True,exist_ok=True)
FIG=OUT/'figures';FIG.mkdir(exist_ok=True);D=OUT/'data';D.mkdir(exist_ok=True)
e=pd.read_csv(BASE/'evidence_dataset.csv',keep_default_na=False)
specs=json.loads((BASE/'data/openai_chart_specs.json').read_text())[:13]
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.titlesize':13,
 'axes.labelsize':10,'svg.fonttype':'none','savefig.facecolor':'white','axes.spines.top':False,
 'axes.spines.right':False,'axes.spines.left':False,'axes.grid':True,'grid.alpha':.15})
BLUE='#2364A2';ORANGE='#C16736';GREEN='#277A64';PURPLE='#7D55A4';GRAY='#6B7480';LIGHT='#F0F3F6'
def save(fig,name,caption):
 fig.text(.03,.02,caption,ha='left',va='bottom',fontsize=8,color=GRAY,wrap=True)
 fig.savefig(FIG/(name+'.png'),dpi=350,bbox_inches='tight')
 fig.savefig(FIG/(name+'.svg'),bbox_inches='tight')
 plt.close(fig)
def csv(rows,name):pd.DataFrame(rows).to_csv(D/name,index=False)
def val(sid,metric,stat=None):
 z=e[(e.source_id==sid)&(e.metric==metric)]
 if stat is not None:z=z[z.statistic==stat]
 return float(z.iloc[0].reported_numeric_value)
def price(model):
 z=e[(e.source_id=='S19')&(e.population_definition==model)]
 return {r.metric.removeprefix('api_price_'):float(r.reported_numeric_value) for _,r in z.iterrows()}
def api_value(model,uncached_input,cached_input,cache_write,visible_output,reasoning):
 p=price(model)
 return (uncached_input*p['input']+cached_input*p['cache_read']+
         cache_write*p['cache_write_5m']+(visible_output+reasoning)*p['output'])/1e6

spend50=pd.DataFrame(specs[1]['data']['values']);spend90=pd.DataFrame(specs[2]['data']['values'])
research50=float(spend50.iloc[-1].value);research90=float(spend90.iloc[-1].value)
external_mean=val('S04','vendor_token_cost','mean')
external90threshold=val('S04','vendor_token_cost','90% of users below threshold')
tokens_research=float(specs[8]['datasets']['totalRows'][-1]['value'])
weekly_messages=val('S05','weekly_user_messages');weekly_users=val('S05','weekly_active_users')
msgs_per_week=weekly_messages/weekly_users;msgs_per_calendar_day=msgs_per_week/7

# Four explicit workload assumptions at ONE fixed reference model, and a price grid.
# These describe a broad consumer-message anchor, NOT the casual-user median.
assumptions=[('short',500,0,0,150,0),('routine',2000,0,0,500,0),
             ('long',20000,0,0,5000,0),('reasoning_heavy',20000,0,0,5000,45000)]
models=['claude-haiku-5.5-short','claude-sonnet-5.5','claude-opus-5.5','claude-fable-5.1']
scenario=[]
for model in models:
 for name,ti,tc,tw,to,tr in assumptions:
  cost=api_value(model,ti,tc,tw,to,tr)*msgs_per_calendar_day
  scenario.append(dict(scenario=name,reference_model=model,user_messages_per_day=msgs_per_calendar_day,
    uncached_input_per_message=ti,cached_input_per_message=tc,cache_write_per_message=tw,
    visible_output_per_message=to,reasoning_output_per_message=tr,
    daily_input=(ti+tc+tw)*msgs_per_calendar_day,daily_output=(to+tr)*msgs_per_calendar_day,
    daily_total=(ti+tc+tw+to+tr)*msgs_per_calendar_day,api_equivalent_usd_day=cost,
    researcher_p50_div_scenario=research50/cost,researcher_p90_div_scenario=research90/cost,
    external_mean_div_scenario=external_mean/cost,
    evidence='assumed workload lengths x measured rounded 2025 consumer message aggregate',
    denominator='weekly-active account / calendar day; not active-day median',source_ids='S05;S19;S02;S04'))
sc=pd.DataFrame(scenario);sc.to_csv(D/'consumer_scenarios.csv',index=False)
ref=sc[sc.reference_model=='claude-sonnet-5.5']

# Cross-source expenditure quotients; not synchronized, fixed-price compute ratios.
ratios=[dict(comparison='OpenAI researcher P50 / external developer mean',metric='source-valued USD/day',
 value=research50/external_mean,lower='',upper='',classification='descriptive cross-source quotient',
 confidence='medium-low',limitations='P50 vs mean; all research employees vs active developers; Aug vs undated; price mixes differ'),
 dict(comparison='OpenAI researcher P90 / external 90%-below threshold',metric='source-valued USD/day',
 value=research90/external90threshold,lower='',upper='',classification='threshold quotient; conditional > interpretation only',
 confidence='medium-low',limitations='External P90 <30 is a vendor bound, not observed P90; daily quantile averaging differs'),
 dict(comparison='OpenAI researcher P90 / P50',metric='API equivalent USD/day',value=research90/research50,
 lower='',upper='',classification='same-source ratio of weekly mean daily quantiles',confidence='high',
 limitations='Not a pooled user-day P90/P50 and not a distribution of individual long-run averages')]
rt=e[e.metric=='daily_agent_runtime_digitized'].copy();rt['value']=rt.reported_numeric_value.astype(float)
rt['lower']=rt.plausible_lower.astype(float);rt['upper']=rt.plausible_upper.astype(float)
rt['population']=rt.population_definition.str.replace(' active Codex accounts','',regex=False)
rt[['population','statistic','value','lower','upper','source_url','source_locator']].to_csv(D/'runtime_percentiles.csv',index=False)
for stat in ['P50','P90','P99']:
 R=rt[(rt.population=='OpenAI')&(rt.statistic==stat)].iloc[0]
 for pop in ['Organizational','Individual']:
  E=rt[(rt.population==pop)&(rt.statistic==stat)].iloc[0]
  ratios.append(dict(comparison='OpenAI employees / '+pop+' Codex accounts ('+stat+')',metric='agent wall-clock hours/active day',
   value=R.value/E.value,lower=R.lower/E.upper,upper=R.upper/E.lower,classification='same-source digitized ratio',
   confidence='medium',limitations='Visual extraction intervals, not CIs; employees not researcher-only; short tool/user waits included'))
for pop,growth in [('Organizational',1.25),('Individual',1.5)]:
 ratios.append(dict(comparison='Change in internal/external P99 runtime ratio vs '+pop,
  metric='ratio of relative growth factors, April-June 2026',value=1.88/growth,lower='',upper='',
  classification='derived from rounded same-source growth',confidence='medium',limitations='Not a 2023-2026 compute-gap time series; active populations can change'))
pd.DataFrame(ratios).to_csv(D/'comparisons.csv',index=False)

# Sensitivity: explicitly hypothetical, no probability distribution or CI.
# f is a toy external activity fraction and k a repricing factor. Internal P50
# is left as reported; changing quantile zero inclusion cannot be done by scaling.
sensitivity=[]
for f in [.5,.75,1.0]:
 for kr in [.5,1,2]:
  for ke in [.5,1,2]:
   sensitivity.append(dict(external_active_day_fraction=f,research_reprice_factor=kr,
    external_reprice_factor=ke,ratio=research50*kr/(external_mean*f*ke),
    interpretation='Assumed calendar-day alignment and price factors; not data-derived bounds'))
csv(sensitivity,'expenditure_sensitivity.csv')

# Normalize only where a denominator exists. Distinct normalized ledger, originals unchanged.
norm=[dict(metric='consumer_user_messages',value=msgs_per_week,unit='messages/weekly active account/week',
 formula='18e9/700e6',source_ids='S05',status='derived from rounded aggregates'),
 dict(metric='consumer_user_messages',value=msgs_per_calendar_day,unit='messages/weekly active account/calendar day',
 formula='18e9/700e6/7',source_ids='S05',status='not daily-active consumption'),
 dict(metric='misteria_messages',value=93/30,unit='messages/monthly active user/calendar day',
 formula='93/30',source_ids='S14',status='September 2026 has 30 calendar days'),
 dict(metric='restricted_research_output',value=tokens_research,unit='output tokens/research employee/day',
 formula='S02 embedded totalRows final value; no active-day conversion',source_ids='S02',status='source estimate, capped and restricted'),
 dict(metric='larry_labs_case',value=130000/30,unit='claimed list-price USD/operator/calendar day',
 formula='130000/30',source_ids='S26',status='self-report n=1, broader scope, no audit')]
csv(norm,'normalized_observations.csv')

# Quarantined Copilot arithmetic: preserve contradictions and prohibit headline reuse.
prompt=val('S11','prompt_tokens');out=val('S11','completion_tokens');calls=val('S11','llm_calls')
turns=val('S11','turns');users=val('S11','users');headline=val('S11','headline_total_tokens')
conflicts=[dict(check='Abstract total vs Table3 prompt+completion',left=headline,right=prompt+out,
 ratio=headline/(prompt+out),status='unreconciled scope or reporting conflict'),
 dict(check='Completion mean/call vs median/call',left=out/calls,right=247,
 ratio=(out/calls)/247,status='if same nonnegative call population, mean must be at least half median'),
 dict(check='Completion total/turn vs Table4 mean/turn',left=out/turns,right=4000,
 ratio=(out/turns)/4000,status='sampling/coverage linkage not disclosed sufficiently to reconcile')]
csv(conflicts,'source_consistency_checks.csv')
csv([dict(population='Copilot Table3, unresolved',input=prompt/users/7,output=out/users/7,
 total=(prompt+out)/users/7,alternative_total_from_abstract=headline/users/7,
 unit='tokens/weekly-observed user/calendar day',eligible_for_headline=False,
 reason='Contradictory published aggregates; cache included in prompt; hidden reasoning excluded')],
 'quarantined_copilot_daily.csv')

# Cumulative Cursor shares are exact accessible chart data, not percentile levels.
tables=json.loads((BASE/'data/cursor_tables.json').read_text())
lorenz=[];mix=[]
for t in tables:
 if 'AI Spend' in str(t[0]) and 'Tokens' in str(t[0]):
  for i,r in enumerate(t[1:],1):
   lorenz.append(dict(user_cumulative_share=i/20,lines=float(r[1].rstrip('%'))/100,
     spend=float(r[2].rstrip('%'))/100,tokens=float(r[3].rstrip('%'))/100,source_id='S09'))
 if t[0]==['Date','Cache Read','Cache Write','Input','Output']:
  for r in t[1:]:mix.append(dict(date=r[0],cache_read=float(r[1].rstrip('%')),
    cache_write=float(r[2].rstrip('%')),input=float(r[3].rstrip('%')),output=float(r[4].rstrip('%'))))
lor=pd.DataFrame(lorenz);csv(lorenz,'cursor_lorenz.csv');csv(mix,'cursor_token_mix.csv')
curve=np.r_[0,lor.tokens.values];grid=np.r_[0,lor.user_cumulative_share.values]
gini_grouped=1-2*np.trapezoid(curve,grid)

# Figure 1: reported valuations and an explicitly separate consumer scenario band.
fig,ax=plt.subplots(figsize=(10.4,5.3));fig.subplots_adjust(left=.36,bottom=.24,right=.86,top=.80)
labels=['Non-users: zero by operational definition','Consumer workload scenarios (not measured)','External Claude Code developers (mean)',
 'OpenAI research employees (P50)','OpenAI research employees (P90)','External operator case (n=1, self-report)']
y=np.arange(len(labels));ax.set_yticks(y,labels);ax.invert_yaxis();ax.set_xscale('log');ax.set_xlim(.003,20000)
ax.text(.004,0,'0 is outside log axis',color=GRAY,va='center')
lo=ref.api_equivalent_usd_day.min();hi=ref.api_equivalent_usd_day.max()
ax.plot([lo,hi],[1,1],color=GRAY,lw=7,alpha=.28);ax.scatter(ref.api_equivalent_usd_day,[1]*4,facecolors='white',edgecolors=GRAY,s=45,zorder=4)
for yy,v,col in [(2,external_mean,GREEN),(3,research50,BLUE),(4,research90,BLUE)]:
 ax.scatter(v,yy,s=90,color=col,zorder=4);ax.annotate(f'${v:,.0f}',(v,yy),xytext=(7,6),textcoords='offset points',color=col)
ax.scatter(130000/30,5,s=70,marker='D',facecolor='white',edgecolor=PURPLE);ax.text(5200,5,'~$4,333',va='center',color=PURPLE)
ax.set_ylim(5.7,-.7)
ax.set_xlabel('USD per person per source-defined day (log scale)')
fig.suptitle('1  |  Expenditure access is uneven; accounting is not uniform',x=.03,ha='left',fontsize=16,fontweight='bold')
fig.text(.03,.87,'Solid dots: reported usage-valued benchmarks. Hollow marks: assumptions or unaudited case.',fontsize=10,color=GRAY)
save(fig,'figure_1_expenditure_gap','Sources: S02, S04, S05, S19, S26. OpenAI: weekly mean daily quantiles, Aug 2026, Sep 3 API prices.\nExternal: undated active-day vendor cost. Consumer band: assumed lengths at Sonnet 5.5 rates; not a confidence interval.')
csv([dict(label=lab,value=v,unit='source USD/day',status=status,source_ids=ids) for lab,v,status,ids in
 [('External mean',external_mean,'vendor benchmark','S04'),('OpenAI P50',research50,'API-equivalent','S02'),('OpenAI P90',research90,'API-equivalent','S02'),('External n1',130000/30,'self-report','S26')]],'figure_1_points.csv')

# Figure 2: missing values visible, rather than inferred from subscription prices.
fig,(a,b)=plt.subplots(1,2,figsize=(11,5.5),gridspec_kw={'width_ratios':[1.1,1]});fig.subplots_adjust(left=.20,bottom=.27,wspace=.5,top=.78)
cats=['Casual consumers','Advanced external users','OpenAI research cohort','Other frontier labs'];a.set_yticks(range(4),cats);a.invert_yaxis();a.set_xlim(0,900000)
a.barh(2,tokens_research,color=BLUE,alpha=.75,hatch='//');a.text(tokens_research+10000,2,'~723k',va='center',color=BLUE)
for yy in [0,1,3]:a.text(30000,yy,'Daily input/output level unavailable',va='center',fontsize=9,color=GRAY)
a.set_ylim(3.7,-.7)
a.set_xlabel('Output tokens / employee / day');a.xaxis.set_major_formatter(FuncFormatter(lambda x,pos:f'{x/1000:.0f}k'))
a.set_title('A. Available daily measurement',loc='left')
b.barh([0,1,2],[227600,217200,1900],color=[GRAY,GREEN,ORANGE]);b.set_yticks([0,1,2],['Prompt (incl. cached)','Cached subset','Completion']);b.invert_yaxis()
b.set_xscale('log');b.set_xlim(100,1e6);b.set_xlabel('Median tokens / external Copilot turn');b.set_title('B. External per-turn evidence',loc='left')
for yy,v in enumerate([227600,217200,1900]):b.annotate(f'{v/1000:g}k',(v,yy),xytext=(5,0),textcoords='offset points',va='center',fontsize=9)
fig.suptitle('2  |  Daily token consumption cannot yet be compared cleanly',x=.03,ha='left',fontsize=16,fontweight='bold')
save(fig,'figure_2_daily_tokens','Sources: S02 (2% session extrapolation, per-user P95 cap, 14-day smoothing, selected R&D tasks); S11 Table 4.\nInput is missing for the research cohort. Panel B is per turn, not per day; cached tokens are a subset of prompt tokens.\nCopilot user-day aggregates are quarantined because published totals cannot be reconciled; reasoning is omitted in S11.')
csv([dict(population=c,input_tokens='',output_tokens=tokens_research if i==2 else '',unit='per source-defined employee-day',
 status='restricted source estimate' if i==2 else 'missing',source_ids='S02' if i==2 else '') for i,c in enumerate(cats)],'figure_2_daily_points.csv')

# Figure 3: runtime distributions provide a same-source three-percentile comparison.
fig,ax=plt.subplots(figsize=(10,5.4));fig.subplots_adjust(bottom=.23,left=.13,right=.9,top=.79)
for pop,col,off in [('OpenAI',BLUE,-.1),('Organizational',GREEN,0),('Individual',ORANGE,.1)]:
 z=rt[rt.population==pop].set_index('statistic').loc[['P50','P90','P99']];v=z.value.values
 ax.errorbar(np.arange(3)+off,v,yerr=np.array([v-z.lower.values,z.upper.values-v]),fmt='o-',color=col,label=pop,capsize=4)
ax.set_xticks(range(3),['Median (P50)','P90','P99']);ax.set_yscale('log');ax.set_ylabel('Agent runtime hours / daily active Codex account');ax.legend(frameon=False,loc='upper left')
ax.text(.48,.92,'No lab-wide inference-dollar P99 is published.',transform=ax.transAxes,color=GRAY,fontsize=9)
fig.suptitle('3  |  Heavy use exists inside and outside the lab',x=.03,ha='left',fontsize=16,fontweight='bold')
save(fig,'figure_3_runtime_inequality','Source: S03 Figure 10, June 11, 2026 endpoint. Most readings digitized; OpenAI 2.5h and ~71h anchored in text.\nBars show visual-reading tolerance, not statistical confidence intervals. Overlapping turns are summed; tools and short waits count.\nThis is agent wall-clock runtime, not GPU-hours or FLOPs; internal accounts cover all employee functions.')

# Figure 4: same-source frozen-price series only. No invented 2023-2025 trend.
fig,ax=plt.subplots(figsize=(10,5.1));fig.subplots_adjust(bottom=.24,left=.12,right=.91,top=.79)
for frame,col,lab in [(spend50,BLUE,'Weekly mean of daily P50'),(spend90,ORANGE,'Weekly mean of daily P90')]:
 z=frame[frame.value>0];ax.plot(pd.to_datetime(z.date),z.value,color=col,label=lab,lw=2)
ax.set_yscale('log');ax.set_ylabel('USD / researcher / calendar day');ax.legend(frameon=False,loc='upper left');ax.set_xlabel('2026 only: January-August')
fig.suptitle('4  |  Internal usage rose quickly; the long-run access gap is unknown',x=.03,ha='left',fontsize=15,fontweight='bold')
fig.text(.03,.87,'No compatible cross-population inference series was found for 2023-2025.',color=GRAY)
save(fig,'figure_4_evolution','Source: S02 embedded data, all observations valued at Sep 3, 2026 retail counterpart prices. Zero-median first weeks omitted on log axis.\nCoverage and model mappings may change. Internal growth alone does not measure widening inequality.\nS03 P99 runtime growth implies April-June gap growth of ~1.50x vs organizations and ~1.25x vs individual accounts.')
csv([dict(date=r.date,value=r.value,statistic=lab,source_id='S02') for lab,frame in [('P50',spend50),('P90',spend90)] for r in frame.itertuples()], 'figure_4_series.csv')

# Figure 5: categorical matrix; no capability scalar or synthetic ranking.
columns=['Public model access','Budget constraints','Context example','Parallel / long work','Unreleased models']
cells=[['Public app\nmodels','Variable free\nquotas','Gemini: 32k','Some tools; no\nmeasured ceiling','Not established'],
 ['Frontier public\nmodels','Plan quotas /\ntop-ups','Gemini paid:\nup to 1M','Agents available;\ntask-dependent','Not established'],
 ['Public API\ncatalog','Spend / rate /\norg limits','Model-specific','Programmatic\norchestration','Limited approved\nprograms'],
 ['Public + internal\ncheckpoints','OpenAI: no\nquantity quota*','Not disclosed','Internal tools;\nconcurrent usage','Documented\nearly access']]
rows=['Free consumer','Paid advanced','API professional','Frontier employee']
fig,ax=plt.subplots(figsize=(10.5,5.4));fig.subplots_adjust(left=.15,right=.98,top=.76,bottom=.2);ax.axis('off')
tab=ax.table(cellText=cells,rowLabels=rows,colLabels=columns,loc='center',cellLoc='left',colWidths=[.18,.21,.18,.23,.20]);tab.auto_set_font_size(False);tab.set_fontsize(10);tab.scale(1,3.2)
for (r,c),cell in tab.get_celld().items():
 cell.set_edgecolor('white');cell.set_linewidth(2);cell.set_facecolor('#DCE7F0' if r==0 else LIGHT if r%2 else '#FFFFFF')
 if r==0:cell.set_text_props(weight='bold')
fig.suptitle('5  |  Access is multidimensional, not one capability score',x=.03,ha='left',fontsize=16,fontweight='bold')
save(fig,'figure_5_capability_matrix','Sources: S03, S17, S21-S23. Supplier-specific examples are not universal tier properties. *OpenAI statement refers to June 2026.\nSecurity permissions still apply; no inference maximum or uniform access to internal models is established for all lab employees.\nRuntime, quotas, context and model quality are distinct; neither higher spend nor more tokens proves proportionate capability.')
csv([dict(population=r,**dict(zip(columns,c)),source_ids='S03;S17;S21;S22;S23') for r,c in zip(rows,cells)],'figure_5_matrix.csv')

# Additional exact, externally observed inequality chart.
fig,ax=plt.subplots(figsize=(7.8,5.2));fig.subplots_adjust(bottom=.2,top=.80)
for field,col in [('tokens',BLUE),('spend',ORANGE)]:ax.plot(grid,np.r_[0,lor[field]],'o-',ms=3,color=col,label=field.title())
ax.plot([0,1],[0,1],'--',color=GRAY,alpha=.65,label='Equal consumption');ax.set_xlabel('Cumulative share of users');ax.set_ylabel('Cumulative share of activity');ax.legend(frameon=False)
ax.xaxis.set_major_formatter(FuncFormatter(lambda x,pos:f'{100*x:.0f}%'));ax.yaxis.set_major_formatter(FuncFormatter(lambda x,pos:f'{100*x:.0f}%'))
fig.suptitle('6  |  Inequality is already substantial among external users',x=.03,ha='left',fontsize=14,fontweight='bold')
save(fig,'figure_6_cursor_lorenz','Source: S09 accessible 20-bin Lorenz table. Reported token Gini 0.72; spend Gini 0.75.\nGrouped linear-interpolation token Gini is lower because within-bin inequality is lost. Percentile levels cannot be inferred from shares.')

# Required requested ratios that remain unidentified, separately documented.
availability=[]
for comparison in ['Researcher / casual','Researcher / advanced professional','Advanced professional / casual','Researcher P90 / casual median']:
 for metric in ['Output tokens/active day','Total tokens/active day','Fixed-price API equivalent/active day','Inference FLOPs/active day']:
  reason='Casual population and absolute token distribution absent; hidden reasoning and activity denominators unknown.'
  if comparison=='Researcher / advanced professional':reason='Internal output is restricted capped mean; external selected aggregate means exist but no matched researcher/professional active-day distributions. Dollar benchmarks cannot be repriced uniformly.'
  if 'FLOPs' in metric:reason+=' Model architecture, cache-adjusted executed tokens, speculative work and hardware data unavailable.'
  availability.append(dict(comparison=comparison,metric=metric,identified=False,ratio='',reason=reason))
csv(availability,'requested_ratio_identification.csv')

summary=dict(cutoff='2026-10-13',evidence_rows=len(e),sources=len(json.loads((BASE/'data/sources.json').read_text())),
 researcher_p50_usd=research50,researcher_p90_usd=research90,external_mean_usd=external_mean,
 cross_source_p50_to_mean=research50/external_mean,p90_to_external_threshold=research90/30,
 internal_p90_to_p50=research90/research50,restricted_research_output_tokens=tokens_research,
 consumer_messages_per_WAU_calendar_day=msgs_per_calendar_day,
 internal_spend_growth_mar1_to_aug15=research50/float(spend50[spend50.date=='2026-03-01'].iloc[0].value),
 internal_spend_growth_jun14_to_aug15=research50/float(spend50[spend50.date=='2026-06-14'].iloc[0].value),
 consumer_ref_scenario_low=lo,consumer_ref_scenario_high=hi,
 sensitivity_ratio_min=min(r['ratio'] for r in sensitivity),sensitivity_ratio_max=max(r['ratio'] for r in sensitivity),
 cursor_grouped_token_gini=gini_grouped,cursor_top10_token_share=1-float(lor[lor.user_cumulative_share==.9].iloc[0].tokens),
 cursor_bottom50_token_share=float(lor[lor.user_cumulative_share==.5].iloc[0].tokens),
 formal_confidence_intervals_computed=False)
(D/'results.json').write_text(json.dumps(summary,indent=2))
# Validation checks verify accounting identities rather than mirroring plotting code.
assert e.observation_id.is_unique
assert abs(weekly_messages/7/weekly_users-msgs_per_calendar_day)<1e-12
assert abs(api_value('claude-sonnet-5.5',1000000,0,0,0,0)-2)<1e-12
assert abs(api_value('claude-sonnet-5.5',0,1000000,0,0,0)-.1)<1e-12
assert np.allclose(sc.daily_total,sc.daily_input+sc.daily_output,rtol=1e-12)
assert len(rt)==9 and tokens_research>0 and len(lor)==20
assert all(np.diff(lor.tokens)>=0) and math.isclose(lor.tokens.iloc[-1],1)
from extended_analysis import extend
summary.update(extend(globals()))
(D/'results.json').write_text(json.dumps(summary,indent=2))
assert len(list(FIG.glob('figure_*.svg')))==8
from PIL import Image as PILImage
for figure_path in FIG.glob('figure_*.png'):
 with PILImage.open(figure_path) as published_image:
  published_image.verify()
print(json.dumps(summary,indent=2))
