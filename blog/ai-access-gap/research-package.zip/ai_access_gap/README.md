# AI Access Gap research package

Evidence cutoff: 2026-10-13. All money is USD.

Start with `research_report.pdf` or `findings_summary.pdf`. The Markdown report is editable and contains direct references. `evidence_dataset.csv` preserves original values and metadata; `source_register.csv` indexes 45 reviewed sources. The 5,353 ledger rows are mostly published time-series points, not independent studies or people. See `revision_notes.md` for the extended-search findings.

## Reproduce

```bash
python -m pip install -r requirements.txt
python analysis.py
python render_report.py
```

Both scripts run offline from supplied inputs. `analysis.py` calls `extended_analysis.py`; keep both together. `analysis.py --output /your/output` regenerates calculated tables and figures elsewhere. Default output is this folder. `render_report.py` builds the two PDFs from the supplied Markdown. Numerical comparisons, assumptions and figure data are in `data/`; eight high-resolution PNGs and eight editable SVGs are in `figures/` (Figure 3 has expenditure and runtime panels exported separately).

## Important distinctions

- Expenditure charts compare source-valued usage; the sources cannot be repriced to one model mix from available data.
- Consumer scenarios are conditional assumed workloads with a broad 2025 message anchor; they are not casual-user measurements or confidence intervals.
- Agent runtime is not accelerator time. Corresponding runtime percentiles describe all OpenAI employees, not researchers alone.
- The restricted OpenAI daily output estimate is sampled and capped; it is not complete consumption or a median.
- Copilot user-day arithmetic is quarantined because published totals cannot be reconciled. Cache counts are a subset of prompt counts.
- Monthly quantiles divided by 30 are daily rates, not daily quantiles. Public submitted-log data select highest-cost windows; user affiliation is unverified.
- The student reconstruction sums prompt-count-weighted token means over 17 calendar days and 37 selected students. It does not use a daily-active denominator or represent casual consumers.
- Exact source values are kept separately from rounded results. No missing value is imputed as zero.

## Provenance

Source IDs link observations and computations to the direct URLs in `source_register.csv`. `openai_chart_specs.json` preserves published numeric chart specifications. `cursor_tables.json` preserves accessible numerical tables. `karpathy_metadata.json` records the original/edit chain and the limitation on primary full-text retrieval. `digitization_protocol.md` explains approximate runtime extraction. `search_audit.md` describes search coverage and exclusions.

Original papers and website bodies are not redistributed. Published numerical values remain attributable to their respective sources. The public Copilot dataset card is included under its CC-BY attribution terms; cite Liu et al. (2026), arXiv:2608.00101. `viberank_snapshot.json` is the original aggregate API response under CC BY 4.0; attribute Viberank, https://www.viberank.app/data, accessed October 13, 2026. No private employee or account data are included.
