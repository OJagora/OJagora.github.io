# Quantifying the AI Access Gap

**One-page findings brief · Updated evidence cutoff: October 13, 2026**

## What can be defended

**The gap depends strongly on the comparison population. No universal physical-compute multiplier is identified.**

| Benchmark | Result | Essential qualification |
| --- | --- | --- |
| OpenAI research expenditure | P50 ~$601/day; P90 ~$7,047/day | Retail-equivalent weekly means of daily quantiles; broad research staff, not all inference |
| Selected public coding users, June | P50 $29/coding day; P90 $215; P99 $708 | Viberank submitted logs; highest-cost windows selected |
| Internal / selected-user expenditure | P50 benchmark **~21x**; P90 **~33x** | Different dates, activity, selection and price bases |
| Other external developer benchmarks | Claude enterprise mean $13/active day; Jellyfish median $52.38/month | These yield very different comparisons; neither is a matched daily median |
| Codex same-product runtime | Corresponding-percentile gaps **~4.5-7.1x** | Active accounts; all internal employees; runtime includes tools and short waits |

Sources: [OpenAI research](https://openai.com/index/research-acceleration-view-inside-openai/), [Viberank June](https://www.viberank.app/blog/state-of-ai-coding-2026), [Claude costs](https://code.claude.com/docs/en/costs), [Jellyfish](https://jellyfish.co/blog/is-tokenmaxxing-cost-effective-new-data-from-jellyfish-explains/), [Codex paper](https://arxiv.org/abs/2606.26959v1).

## New measured token anchors

OpenAI's sampled, capped estimate is **~723,000 output tokens/research employee/day**. Viberank's matching rounded totals imply **~202,000 output tokens/active coding day**, giving a **~3.6x heterogeneous benchmark**. A [small academic study](https://doi.org/10.1145/3772363.3798840) implies **~1,005 output tokens/student/calendar day** for 37 selected users on one platform, giving **~719x**. These distinct scopes do not identify a casual-user median or a physical-compute ratio.

The [October Viberank snapshot](https://www.viberank.app/data) reports a selected-window median of **$1,521 per normalized month**. Dividing by 30 yields a daily rate, not a daily quantile. Its lab affiliations are unverified; it is not a representative external-professional sample.

## What remains missing

The broad [consumer study](https://cdn.openai.com/pdf/a253471f-8260-40c6-a2cc-aa93fe9f142e/economic-research-chatgpt-usage-paper.pdf) provides **~3.67 messages/weekly-active account/calendar day**, without full tokens or a casual median. Matched model, cache, hidden-reasoning and person-day records remain absent across tiers. No reliable FLOP, GPU-hour or energy multiplier can be published. Karpathy's full original-versus-edited long-post wording remains only partially primary-verified.

## Article-ready conclusion

The evidence supports substantial, uneven use of AI. It supports selected expenditure benchmarks from tens to hundreds of times, alongside smaller same-product runtime and some output-token comparisons. Those quotients describe different populations and accounting rules; they are not bounds on one universal gap. **Do not substitute subscriptions for consumption, agent-hours for GPU-hours, or greater token volume for proportionately greater capability.**

The expanded package contains 45 source records, 5,353 observations and eight figure pairs. Missing values and conflicting Copilot totals remain explicit; scenario ranges are not confidence intervals.
