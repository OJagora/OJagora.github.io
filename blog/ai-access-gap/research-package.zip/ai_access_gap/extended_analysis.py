"""Additional frozen evidence collected during the second research pass.

Called by analysis.py. Original monthly observations remain monthly. Dividing a
monthly quantile by 30 creates a 30-day rate, never an observed daily quantile.
No confidence interval is inferred from rounded aggregates or leaderboard data.
"""
def extend(g):
 import json
 import numpy as np
 import pandas as pd
 import matplotlib.pyplot as plt
 from matplotlib.ticker import FuncFormatter
 e=g['e'];D=g['D'];FIG=g['FIG'];save=g['save'];val=g['val'];csv=g['csv']
 BLUE=g['BLUE'];GREEN=g['GREEN'];ORANGE=g['ORANGE'];PURPLE=g['PURPLE'];GRAY=g['GRAY']
 r50=g['research50'];r90=g['research90'];rout=g['tokens_research'];ref=g['ref']
 def v(s,m,stat=None,pop=None):
  z=e[(e.source_id==s)&(e.metric==m)]
  if stat is not None:z=z[z.statistic==stat]
  if pop is not None:z=z[z.population_definition==pop]
  assert len(z)==1,(s,m,stat,pop,len(z))
  return float(z.iloc[0].reported_numeric_value)
 jelly50=v('S34','monthly_api_equivalent_cost','P50')/30
 jelly90=v('S34','monthly_api_equivalent_cost','P90')/30
 june50=v('S36','daily_api_equivalent_cost','P50');june90=v('S36','daily_api_equivalent_cost','P90')
 june99=v('S36','daily_api_equivalent_cost','P99')
 vibe50=v('S37','normalized_monthly_api_equivalent_cost','P50')/30
 vibe90=v('S37','normalized_monthly_api_equivalent_cost','P90')/30
 vibe99=v('S37','normalized_monthly_api_equivalent_cost','P99')/30
 codingdays=v('S36','coding_user_days');vibe_total=v('S36','total_tokens')/codingdays
 vibe_out=v('S36','output_tokens')/codingdays
 students=[]
 # Figure 5 confirms July 8 through July 24 inclusive: 17 calendar days.
 # Reconstruct aggregate totals using prompt-weighted means, then divide by
 # people*days. A product of unrelated per-person and per-prompt means is avoided.
 for pop in ['Tracker present','No tracker']:
  n=v('S38','participants',pop=pop);p=v('S38','prompts',pop=pop)
  ti=v('S38','input_tokens_per_prompt',pop=pop);to=v('S38','output_tokens_per_prompt',pop=pop)
  students.append(dict(group=pop,students=n,prompts=p,calendar_days=17,
   input_tokens_per_prompt=ti,output_tokens_per_prompt=to,
   daily_input=p*ti/n/17,daily_output=p*to/n/17,
   denominator='Selected cohort student / calendar day, July 8-24 inclusive',
   confidence='Rounded prompt aggregates; no cluster CI',source_id='S38'))
 ni=sum(x['students'] for x in students)
 si=sum(x['daily_input']*x['students'] for x in students)/ni
 so=sum(x['daily_output']*x['students'] for x in students)/ni
 students.append(dict(group='Combined',students=ni,prompts=sum(x['prompts'] for x in students),calendar_days=17,
  input_tokens_per_prompt='',output_tokens_per_prompt='',daily_input=si,daily_output=so,
  denominator='37 selected students / calendar day; not daily active',confidence='No population-representative inference or daily median',source_id='S38'))
 csv(students,'student_daily_reconstruction.csv')
 assert sum(x['prompts'] for x in students[:2])==781 and ni==37
 # Pooled prompt-weighted reconstruction identity.
 assert np.isclose(so*37*17,375*740.2+406*873.3)
 student_ref=g['api_value']('claude-sonnet-5.5',si,0,0,so,0)
 mix=[v('S36',m)/100 for m in ['uncached_input_share','cache_read_share','cache_write_share','output_share']]
 assert np.isclose(sum(mix),1)
 repriced=[]
 for model in ['claude-haiku-5.5-short','claude-sonnet-5.5','claude-opus-5.5','claude-fable-5.1']:
  cost=g['api_value'](model,*[vibe_total*m for m in mix[:3]],vibe_total*mix[3],0)
  bad=g['api_value'](model,vibe_total*(1-mix[3]),0,0,vibe_total*mix[3],0)
  repriced.append(dict(reference_model=model,total_processed_tokens_per_coding_day=vibe_total,
   uncached_input=vibe_total*mix[0],cache_read=vibe_total*mix[1],cache_write=vibe_total*mix[2],output=vibe_total*mix[3],
   correct_api_value=cost,ignoring_cache_discounts=bad,overvaluation_factor=bad/cost,
   status='Fixed-price reference valuation of rounded measured aggregate mix; no reasoning added',source_ids='S36;S19'))
 csv(repriced,'cache_aware_reference_valuation.csv')
 benchmark=[]
 for cohort,stat,value,denom,ids in [
  ('Jellyfish Q1','P50',jelly50,'Monthly P50 /30, not daily P50','S34'),
  ('Jellyfish Q1','P90',jelly90,'Monthly P90 /30, not daily P90','S34'),
  ('Viberank June','P50',june50,'Tracked coding user-day P50','S36'),
  ('Viberank June','P90',june90,'Tracked coding user-day P90','S36'),
  ('Viberank June','P99',june99,'Tracked coding user-day P99','S36'),
  ('Viberank October snapshot','P50',vibe50,'30-day normalized submission P50 /30','S37'),
  ('Viberank October snapshot','P90',vibe90,'30-day normalized submission P90 /30','S37'),
  ('Viberank October snapshot','P99',vibe99,'30-day normalized submission P99 /30','S37')]:
  numerator=r50 if stat=='P50' else r90 if stat=='P90' else None
  benchmark.append(dict(cohort=cohort,source_statistic=stat,daily_rate_usd=value,denominator=denom,
   internal_same_percentile_quotient=numerator/value if numerator else '',
   status='Descriptive cross-source valuation; heterogeneous price bases, dates, day and selection rules',source_ids='S02;'+ids))
 csv(benchmark,'additional_expenditure_benchmarks.csv')
 csv([dict(source_id=s,metric=m,numerator_stat=ns,denominator_stat=ds,
  ratio=num/den,interpretation='Within-source distribution quotient; no confidence interval') for s,m,ns,ds,num,den in
  [('S34','monthly_api_equivalent_cost','P90','P50',jelly90,jelly50),
   ('S36','daily_api_equivalent_cost','P90','P50',june90,june50),
   ('S36','daily_api_equivalent_cost','P99','P50',june99,june50),
   ('S37','normalized_monthly_api_equivalent_cost','P90','P50',vibe90,vibe50),
   ('S37','normalized_monthly_api_equivalent_cost','P99','P50',vibe99,vibe50)]],
  'additional_within_population_ratios.csv')
 addedratios=[dict(comparison='Restricted OpenAI output / Viberank June output mean',metric='output token benchmark',
  value=rout/vibe_out,lower='',upper='',classification='heterogeneous benchmark quotient',confidence='low',
  limitations='Capped calendar-day internal estimate vs uncapped submitted coding-day external mean; dates and reasoning coverage differ'),
  dict(comparison='Restricted OpenAI output / selected student calendar-day mean',metric='output token benchmark',
  value=rout/so,lower='',upper='',classification='heterogeneous benchmark quotient',confidence='low',
  limitations='2026 capped selected-task employee mean / 2025 optional intervention-platform cohort; not casual-user median'),
  dict(comparison='Enterprise frontier/typical output gap growth Jan-Jun',metric='ratio of ratios',
  value=8.3/2.6,lower='',upper='',classification='same-provider source-defined firm group comparison',confidence='medium',
  limitations='Monthly re-ranking; frontier firms are not AI laboratories; no absolute daily tokens')]
 for r in benchmark:
  if r['internal_same_percentile_quotient']!='':addedratios.append(dict(comparison='OpenAI / '+r['cohort']+' '+r['source_statistic'],
   metric='source-valued USD daily rate',value=r['internal_same_percentile_quotient'],lower='',upper='',
   classification='descriptive cross-source quotient',confidence='low-medium',limitations=r['status']+'; '+r['denominator']))
 old=pd.read_csv(D/'comparisons.csv');pd.concat([old,pd.DataFrame(addedratios)]).to_csv(D/'comparisons.csv',index=False)
 oldn=pd.read_csv(D/'normalized_observations.csv')
 newn=[dict(metric='selected_student_output',value=so,unit='output tokens/selected student/calendar day',formula='(375*740.2+406*873.3)/(37*17)',source_ids='S38',status='Derived; single platform; selection and intervention'),
 dict(metric='selected_student_input',value=si,unit='input tokens/selected student/calendar day',formula='(375*7427.1+406*13468)/(37*17)',source_ids='S38',status='Derived; full input composition not disclosed'),
 dict(metric='viberank_june_output',value=vibe_out,unit='output tokens/submitted active coding user-day',formula='5.9e9/29230',source_ids='S36',status='Derived from rounded totals; highest-cost submission selection'),
 dict(metric='viberank_june_total',value=vibe_total,unit='total tokens/submitted active coding user-day',formula='2.5e12/29230',source_ids='S36',status='Derived; mostly cache reads; not FLOPs')]
 pd.concat([oldn,pd.DataFrame(newn)]).to_csv(D/'normalized_observations.csv',index=False)

 # Figure 1 revised: no single external-professional denominator is imposed.
 fig,ax=plt.subplots(figsize=(11,6.4));fig.subplots_adjust(left=.39,bottom=.23,right=.89,top=.80)
 labels=['Non-users: deliberate use = zero','Consumer workload scenarios (assumed)',
 'Jellyfish company developers: monthly P50 /30','Claude Code enterprise developers: mean',
 'Viberank June: selected coding-day P50','Viberank October: selected monthly P50 /30',
 'OpenAI research employees: daily P50','OpenAI research employees: daily P90','External operator self-report: n=1']
 ax.set_yticks(range(len(labels)),labels);ax.set_xscale('log');ax.set_xlim(.003,20000);ax.set_ylim(8.6,-.7)
 ax.text(.004,0,'Zero is outside log axis',va='center',color=GRAY)
 lo=ref.api_equivalent_usd_day.min();hi=ref.api_equivalent_usd_day.max()
 ax.plot([lo,hi],[1,1],color=GRAY,lw=7,alpha=.28);ax.scatter(ref.api_equivalent_usd_day,[1]*4,facecolor='white',edgecolor=GRAY,s=40)
 pts=[(2,jelly50,GREEN,'s',False),(3,13,GREEN,'o',True),(4,june50,PURPLE,'D',True),(5,vibe50,PURPLE,'s',False),
 (6,r50,BLUE,'o',True),(7,r90,BLUE,'o',True),(8,130000/30,ORANGE,'D',False)]
 for y,x,c,m,solid in pts:
  ax.scatter(x,y,marker=m,s=70,facecolor=c if solid else 'white',edgecolor=c,zorder=5)
  ax.annotate(f'${x:,.2f}' if x<100 else f'${x:,.0f}',(x,y),xytext=(7,5),textcoords='offset points',color=c,fontsize=9)
 ax.set_xlabel('USD per person per source-defined day or normalized 30-day rate (log scale)')
 fig.suptitle('1  |  The expenditure gap depends on which users are compared',x=.03,ha='left',fontsize=16,fontweight='bold')
 fig.text(.03,.87,'Dots/diamonds: reported daily benchmarks. Hollow squares: monthly values divided by 30.',color=GRAY,fontsize=10)
 save(fig,'figure_1_expenditure_gap','Sources: S02, S04, S05, S19, S26, S34, S36-S37. Price bases and populations differ. No statistical confidence intervals.\nViberank selects highest-cost submitted windows; lab affiliation is unverified. Monthly /30 values are not daily quantiles.\nConsumer band is an assumed workload set, not measured population bounds. Internal: weekly means of daily quantiles.')
 csv([dict(label=labels[y],value=x,unit='USD/source day or 30-day rate',source_ids=ids,status=st) for y,x,ids,st in
 [(2,jelly50,'S34','monthly /30'),(3,13,'S04','active-day mean'),(4,june50,'S36','submitted coding-day P50'),
 (5,vibe50,'S37','normalized monthly /30'),(6,r50,'S02','weekly mean daily P50'),(7,r90,'S02','weekly mean daily P90'),(8,130000/30,'S26','n1 self-report')]],'figure_1_points.csv')

 # Figure 2: input/output daily means and separate total-token benchmarks.
 fig,(a,b)=plt.subplots(1,2,figsize=(11.4,6),gridspec_kw={'width_ratios':[1.2,1]});fig.subplots_adjust(left=.24,bottom=.28,right=.97,wspace=.56,top=.78)
 names=['Selected students (calendar-day mean)','Viberank June (coding-day mean)','OpenAI (restricted employee mean)','Casual consumer median']
 a.set_yticks(range(4),names);a.set_xscale('log');a.set_xlim(400,2e8);a.set_ylim(3.6,-.7)
 for y,inp,out,col in [(0,si,so,GREEN),(1,vibe_total-vibe_out,vibe_out,PURPLE),(2,None,rout,BLUE)]:
  a.scatter(out,y+.10,color=ORANGE,s=55,label='Output' if y==0 else None)
  if inp is not None:a.scatter(inp,y-.10,color=GREEN,s=55,label='Input incl. cached' if y==0 else None)
  else:a.text(1.5e6,y-.12,'Input missing',color=GRAY,fontsize=8)
 a.text(1200,3,'Not identified',va='center',color=GRAY);a.legend(frameon=False,fontsize=9,loc='lower right')
 a.set_xlabel('Tokens/person/source-defined day (log)');a.set_title('A. Daily input/output benchmark means',loc='left',fontsize=11)
 totals=[51e6/30,380e6/30,vibe_total];labels2=['Jellyfish P50 month /30','Jellyfish P90 month /30','Viberank coding-day mean']
 b.set_yticks(range(3),labels2);b.set_xscale('log');b.set_xlim(6e5,2e8);b.set_ylim(2.6,-.6)
 for y,x in enumerate(totals):
  b.scatter(x,y,marker='s',facecolor='white',edgecolor=PURPLE,s=60)
  b.annotate(f'{x/1e6:.2g}M',(x,y),xytext=(6,6),textcoords='offset points',fontsize=9)
 b.set_title('B. Total tokens: different statistics',loc='left',fontsize=11);b.set_xlabel('Processed tokens/person/day rate (log)')
 fig.suptitle('2  |  Daily token benchmarks exist; coverage remains unequal',x=.03,ha='left',fontsize=16,fontweight='bold')
 save(fig,'figure_2_daily_tokens','Sources: S02, S34, S36, S38. All displayed normalized values are derived from published values; no daily-active consumer median.\nStudents: 37 selected users, 17 calendar days, July 2025, one platform. Viberank: rounded aggregates /29,230 coding user-days.\nOpenAI: sampled, capped, selected-task output estimate. Cache reads dominate external totals; token counts are not physical compute.')
 csv([dict(population=names[0],input_tokens=si,output_tokens=so,source_ids='S38',denominator='37 students x17 calendar days'),
 dict(population=names[1],input_tokens=vibe_total-vibe_out,output_tokens=vibe_out,source_ids='S36',denominator='29,230 coding user-days'),
 dict(population=names[2],input_tokens='',output_tokens=rout,source_ids='S02',denominator='research employee; restricted source estimate'),
 dict(population=names[3],input_tokens='',output_tokens='',source_ids='',denominator='unidentified')],'figure_2_daily_points.csv')

 # Figure 3A: daily and monthly-rate quantiles stay in separate panels.
 fig,(a,b)=plt.subplots(1,2,figsize=(10.8,5.8));fig.subplots_adjust(bottom=.27,left=.09,right=.98,wspace=.26,top=.78)
 for ax,series in [(a,[('OpenAI: daily q average',[r50,r90,np.nan],BLUE),('Viberank June: coding days',[june50,june90,june99],PURPLE)]),
 (b,[('Jellyfish Q1: monthly q /30',[jelly50,jelly90,np.nan],GREEN),('Viberank snapshot: monthly q /30',[vibe50,vibe90,vibe99],ORANGE)])]:
  for label,values,col in series:ax.plot(range(3),values,'o-',color=col,label=label)
  ax.set_xticks(range(3),['P50','P90','P99']);ax.set_yscale('log');ax.set_ylim(.8,20000);ax.legend(frameon=False,fontsize=8,loc='upper left')
 a.set_title('A. Source-reported daily distributions',fontsize=11,loc='left');b.set_title('B. Monthly distributions /30',fontsize=11,loc='left')
 a.set_ylabel('USD per source day or 30-day normalized rate');b.text(1.93,1.15,'Lab P99 unavailable',color=GRAY,ha='right',fontsize=8)
 fig.suptitle('3A  |  Within-population expenditure inequality is substantial',x=.03,ha='left',fontsize=15,fontweight='bold')
 save(fig,'figure_3_expenditure_inequality','Sources: S02, S34, S36-S37. Blank P99 endpoints are unavailable. Monthly quantiles /30 are not daily quantiles.\nDifferent source dates, price schedules, activity and selection rules; no confidence intervals from these summaries.\nViberank highest-cost submissions are self-selected; percentile distributions are not representative of all professionals.')
 csv(benchmark,'figure_3_external_data.csv')

 # Figure 3B keeps the original coherent runtime comparator, clearly renamed.
 fig,ax=plt.subplots(figsize=(10,5.4));fig.subplots_adjust(bottom=.23,left=.13,right=.9,top=.79)
 for pop,col,off in [('OpenAI',BLUE,-.1),('Organizational',GREEN,0),('Individual',ORANGE,.1)]:
  z=g['rt'][g['rt'].population==pop].set_index('statistic').loc[['P50','P90','P99']];x=z.value.values
  ax.errorbar(np.arange(3)+off,x,yerr=[x-z.lower.values,z.upper.values-x],fmt='o-',color=col,label=pop,capsize=4)
 ax.set_xticks(range(3),['Median (P50)','P90','P99']);ax.set_yscale('log');ax.set_ylabel('Agent runtime hours / daily active Codex account');ax.legend(frameon=False)
 fig.suptitle('3B  |  Same-product runtime gaps are smaller than many dollar gaps',x=.03,ha='left',fontsize=15,fontweight='bold')
 save(fig,'figure_3_runtime_inequality','Source: S03 Figure 10, June 11, 2026. Digitization ranges are visual tolerance, not statistical confidence intervals.\nOverlapping turns are summed; tools and short waits count. This is wall-clock agent runtime, not GPU-hours or FLOPs.\nInternal accounts cover all employee functions; external accounts already use coding agents.')

 # Figure 4 adds a coherent external inequality series, not a lab/consumer gap.
 fig,(a,b)=plt.subplots(1,2,figsize=(11,5.5),gridspec_kw={'width_ratios':[1.45,1]});fig.subplots_adjust(bottom=.26,left=.09,right=.96,wspace=.28,top=.77)
 for frame,col,label in [(g['spend50'],BLUE,'Internal daily P50'),(g['spend90'],ORANGE,'Internal daily P90')]:
  z=frame[frame.value>0];a.plot(pd.to_datetime(z.date),z.value,color=col,label=label)
 a.set_yscale('log');a.set_ylabel('USD/researcher/calendar day');a.legend(frameon=False,fontsize=8);a.set_title('A. Internal fixed-price usage valuation',fontsize=11,loc='left')
 a.tick_params(axis='x',labelrotation=30,labelsize=8)
 b.plot([0,1],[2.6,8.3],'o--',color=PURPLE);b.set_xticks([0,1],['Jan 2026','June 2026']);b.set_ylim(0,10)
 b.set_ylabel('Frontier/typical firm output-token ratio');b.set_title('B. External enterprise intensity inequality',fontsize=11,loc='left')
 for x,y in enumerate([2.6,8.3]):b.annotate(f'{y:g}x',(x,y),xytext=(5,6),textcoords='offset points',color=PURPLE)
 fig.suptitle('4  |  Some 2026 gaps widened; the 2023-2026 lab gap is unmeasured',x=.03,ha='left',fontsize=15,fontweight='bold')
 save(fig,'figure_4_evolution','Sources: S02 (Sep 3 fixed retail counterpart prices); S40 (monthly re-ranked firm groups, top 10% vs middle 10%).\nPanel B shows published endpoints; the dashed connection does not imply measured intermediate values or a fixed firm panel.\nFrontier enterprise means high usage, not an AI laboratory. No compatible all-tier 2023-2026 physical-compute series exists.')
 csv([dict(period=p,frontier_typical_ratio=x,source_id='S40',definition='top10% firms /45th-55th percentile, re-ranked each month') for p,x in [('2026-01',2.6),('2026-06',8.3)]],'enterprise_gap_series.csv')

 # Figure 7: proper token pricing vs silently treating cache reads as new input.
 z=pd.DataFrame(repriced);fig,ax=plt.subplots(figsize=(9.7,5.5));fig.subplots_adjust(left=.24,bottom=.25,right=.94,top=.78)
 for i,row in z.iterrows():
  ax.scatter(row.correct_api_value,i,color=GREEN,s=60,label='Cache-aware reference valuation' if i==0 else None)
  ax.scatter(row.ignoring_cache_discounts,i,facecolor='white',edgecolor=ORANGE,marker='s',s=60,label='Incorrect: all input at uncached rate' if i==0 else None)
  ax.plot([row.correct_api_value,row.ignoring_cache_discounts],[i,i],color=GRAY,alpha=.45)
 ax.set_yticks(range(4),['Haiku 5.5 short','Sonnet 5.5','Opus 5.5','Fable 5.1']);ax.set_xscale('log');ax.invert_yaxis()
 ax.set_xlabel('USD/active coding day at chosen reference-model prices');ax.legend(frameon=False,fontsize=9,loc='upper left',bbox_to_anchor=(0,1.20))
 fig.suptitle('7  |  Cache accounting can change the valuation by many times',x=.03,ha='left',fontsize=15,fontweight='bold')
 save(fig,'figure_7_cache_accounting','Sources: S36 rounded aggregate traffic mix and total /29,230 coding days; S19 October 13 standard public prices.\nThese are fixed-model workload-price scenarios, not actual bills or quality-equivalent models. Price functions distinguish cache writes.\nThe 5.9B reported output total and rounded 0.2% share differ slightly; this figure uses the four rounded shares, which sum to 100%.')

 return dict(jellyfish_monthly_p50_usd=52.38,jellyfish_monthly_p90_usd=691.14,
  researcher_div_jellyfish_p50_30day_rate=r50/jelly50, researcher_div_viberank_june_p50=r50/june50,
  researcher_div_viberank_snapshot_p50_30day_rate=r50/vibe50,
  viberank_june_output_per_coding_day=vibe_out,viberank_june_total_per_coding_day=vibe_total,
  selected_student_calendar_day_input=si,selected_student_calendar_day_output=so,
  restricted_researcher_div_selected_student_output=rout/so,restricted_researcher_div_viberank_output=rout/vibe_out,
  student_reference_sonnet_daily_usd=student_ref,enterprise_gap_growth_jan_jun=8.3/2.6,
  cache_aware_sonnet_reference_daily_usd=float(z[z.reference_model=='claude-sonnet-5.5'].iloc[0].correct_api_value),
  formal_confidence_intervals_computed=False,figure_exports=8)
