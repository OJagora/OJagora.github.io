# Extended evidence search: revision notes

Evidence cutoff remains October 13, 2026. The update adds 12 sources and 133 original observations, bringing the ledger to 45 sources and 5,353 rows. This is a structured search, not a claim of exhaustive coverage.

The earlier 46.3x OpenAI researcher-median / Anthropic developer-mean expenditure quotient is retained. It is no longer presented as the single closest comparison. Viberank's source-reported coding-day median supports a 20.7x descriptive median benchmark, while lower-intensity company telemetry and selected normalized-window distributions yield different comparisons.

New token reconstructions use matching aggregate denominators: Viberank coding user-days and a selected academic student panel. They supply heterogeneous output benchmarks of roughly 3.6x and 719x respectively. Neither identifies casual consumers or a physical-compute ratio.

Monthly quantiles are preserved as monthly. Their optional division by 30 is explicitly a normalized rate, not a daily quantile. Viberank's voluntary and highest-window selection, and unverified laboratory affiliations, remain visible.

The figure suite now adds expenditure distributions and cache-aware reference pricing, and separates internal fixed-price evolution from external enterprise inequality. All original source values remain distinct from calculations. The dataset records a source-reported student per-prompt confidence interval, but no access-gap confidence interval is invented.

Copilot's conflicting totals remain unreconciled after checking the current v1 abstract, HTML tables and methods. A revised title alone does not resolve the discrepancy. The original quarantined arithmetic stays excluded from headline figures.

Additional Meta token reports, enterprise budgets, concurrency measurements, a developer log audit and AgentX trace metadata are retained with their different evidence status and missing denominators. No new company-published per-researcher distribution for another frontier laboratory was identified.
