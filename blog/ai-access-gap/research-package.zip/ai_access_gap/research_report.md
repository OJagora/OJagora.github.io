# Quantifying the AI Access Gap

## An evidence audit of inference consumption, expenditure and capability access

**Evidence cutoff: 13 October 2026.** Prepared for Octave Jagora. All monetary figures are USD. This report contains 45 source records and 5,353 evidence-ledger rows. Most rows are observations within published time series, not independent studies or independent people. The investigation is a structured research audit, not a preregistered systematic review.

## Executive summary

There is credible evidence that some frontier-laboratory employees use substantially more AI than external users. There is **no defensible single estimate of the frontier-researcher/casual-user inference-compute ratio** in the public evidence reviewed. The external denominator strongly changes the expenditure comparison: approximately **21 times** against selected Viberank coding-day medians, **46 times** against Anthropic's enterprise active-day mean, and much larger quotients against lower-intensity company telemetry. These are heterogeneous benchmarks, not a population-wide range. A more internally consistent comparison of Codex agent runtime gives approximately **4.5 to 7.1 times** at corresponding percentiles. Neither result measures GPU-hours or model capability.

The main quantitative findings are:

| Finding | Result | Evidence status |
| --- | --- | --- |
| OpenAI research-organization daily inference valuation | P50 approximately **$601/day**; P90 approximately **$7,047/day** | Exact numerical chart data, weekly averages of daily percentiles; August 2026, September 3 API prices [S02] |
| External Claude Code enterprise developer usage | Mean approximately **$13/active day**; 90% of users below **$30/active day** | Vendor benchmark; sample, dates and complete price methodology undisclosed [S04] |
| Internal/external expenditure quotient | **46.3×** for laboratory P50/external mean; **234.9×** against the external $30 threshold | Descriptive source-valued quotients, not standardized compute ratios [S02, S04] |
| Same-source daily Codex runtime | OpenAI P50 **2.5h**; external organizational approximately **0.42h**, individual approximately **0.55h** | Active-day comparison; external endpoints digitized [S03] |
| Same-source upper-tail runtime | OpenAI P99 approximately **71h**; external organizational approximately **12.4h**, individual approximately **15.5h** | Approximately **5.7×** and **4.6×**; overlapping turns summed [S03] |
| Selected public developer coding-day expenditure | P50 **$29**, P90 **$215**, P99 **$708** | Submitted local logs, June 2026; highest-cost windows selected [S36] |
| External company developer monthly expenditure | P50 **$52.38**, P90 **$691.14** | Jellyfish Q1 telemetry, 12,000 developers/200 companies; not daily quantiles [S34] |
| Derived selected-user output benchmarks | Students **~1,005/calendar day**; Viberank **~202,000/coding day** | Rounded aggregate reconstructions; distinct scopes and dates [S36, S38] |
| Absolute internal output-token evidence | Approximately **723,000 output tokens/research employee/day** | Sample-extrapolated, capped, selected-task mean; not median or complete consumption [S02] |
| Broad consumer activity anchor | Approximately **3.67 user messages/weekly active account/calendar day** | Rounded July 2025 aggregate; token lengths and casual-user median missing [S05] |

The expenditure gap can be large while the runtime gap is smaller: different models, reasoning budgets, cache reuse, processing tiers and harnesses can produce very different dollar valuations per agent-hour. The available data do not permit decomposing those effects.

Consumer scenarios illustrate sensitivity rather than identify a population ratio. At one fixed public reference price, assumed message workloads produce daily valuations ranging from approximately $0.009 to $1.98. Combining those assumptions with the internal benchmark produces large conditional ratios, but these are neither observed gaps nor empirical lower and upper bounds.

A second research pass adds external developer distributions, a logged student study, enterprise inequality trends and budget/trace evidence. The most important missing measurement is a matched, person-day token ledger across consumer, external professional and internal researcher populations, including model identity, cache accounting and hidden reasoning. Until that exists, an article should distinguish **large expenditure differences**, **moderate same-product runtime differences**, and an **unidentified physical-compute gap**.

## 1. Research questions and scope

The principal question is how much more inference a frontier researcher consumes, or is allowed to consume, relative to an ordinary user or advanced external professional. Three related questions must be answered separately: how much inference actually runs, what a public API would charge for it, and which capabilities a person can access.

The target estimand for consumption is a distribution over people and days. Ideally, each observation would include uncached input, cached input, cache writes, visible output, hidden reasoning, model calls and attribution of downstream agents. The preferred population denominator is a person active on that day, accompanied by an all-person calendar-day version. Both matter: conditioning on use measures intensity, while including zero-use days measures realized access across a population.

The scope excludes training compute from inference totals and excludes customer-serving production workloads from an employee's own research consumption unless separately identified. Experimental agent systems may incur both inference and training costs; their aggregate budgets remain useful evidence about available infrastructure but cannot be treated as personal daily inference.

The cutoff applies to information available by October 13, 2026. Undated live documentation is recorded as an October 13 snapshot, not backdated to a known research measurement period. The latest usable observations occur at different times; no fully synchronized October 2026 comparison was identified.

## 2. Karpathy's argument and publication history

The widely shared URL is [Karpathy's edited X post](https://x.com/karpathy/status/2109361546505966046). Primary X page metadata gives **October 11, 2026, 19:12:37 UTC** for that version. Public X syndication metadata identifies an initial post, [2109361082217402758](https://x.com/karpathy/status/2109361082217402758), at **19:10:46 UTC**, with the later ID in its edit chain. Those times are respectively 21:12:37 and 21:10:46 in Paris. Snowflake-ID timestamps independently agree to subsecond precision. The post is therefore correctly dated October 11, with an original-versus-edited timestamp distinction. [S01]

The opening and first population estimate were recoverable from primary metadata. Primary public syndication returned only truncated text and a note-tweet identifier for the long post. The full wording was available in an [unofficial October 12 archive](https://postcutoff.com/p/2026-10-11-karpathy-capability-gap-funnel/), which is used for the following paraphrase. **The complete wording of both versions and changes between them could not be independently verified from primary text.** The recovered exact short phrase is “more a sharp funnel.” This limitation should accompany any claim to quote the entire original post. [S01, S29]

| Described tier | Informal estimate | Operational meaning |
| --- | --- | --- |
| Little exposure to LLMs | About 6 billion, approximately 75% | Barely encountered meaningful LLM use |
| Casual, infrequent free-tier use | About 1–2 billion, approximately 20% | Search-like assistance, writing help and limited agent exposure |
| Professional frontier-model use in mathematics and code | About 20 million, approximately 0.2% | Complex technical projects and substantial agent delegation |
| Internal frontier-system access | About 5,000, approximately 0.00006% | Internal systems, long-running parallel work and advanced research infrastructure |

These are Karpathy's informal estimates, not measured sampling frames. His framing concerns first-hand understanding of capability as much as access. The mechanisms he proposes include problem ambition, concentration of progress in verifiable technical work, and access tiers. None of the counts determines daily inference intensity. The tiers need not be exclusive: a researcher can also use a free chatbot casually, and a professional can belong to different tiers across tasks. The internal-access estimate is not a verified laboratory headcount. [S29]

## 3. Population definitions for this analysis

| Analysis category | Useful subdivisions | Main identification issue |
| --- | --- | --- |
| Non-users | No deliberate generative-AI use; minimal exposure | Deliberate consumption is zero by definition, but embedded AI can run without conscious use |
| Casual users | Free consumer accounts; occasional subscribers | Consumer-plan labels do not identify casual behavior |
| Regular and advanced external users | Standard paid; premium paid; enterprise seats; personal API users; organization-funded users | Plan, professional role and usage intensity are different variables |
| Frontier employees | Research staff; research infrastructure; engineering; other functions | Employee status does not imply uniform access or usage |

OpenAI's research disclosure uses a broad research-organization population, including infrastructure and management support. Its Codex paper instead distinguishes internal employees, organizational accounts and individual accounts. Those account types are not equivalent to Karpathy's tiers. External individual Codex users are already a selected set of agent users, not ordinary casual chatbot users. [S02, S03]

An enterprise API account can represent one developer, thousands of customers, or an automated production service. Organizational token aggregates therefore cannot be divided by employee count and called personal consumption without attribution. Conversely, an individual with multiple subscriptions or API access can run more inference than some laboratory employees. The study preserves that possibility instead of imposing a monotonic tier ordering.

## 4. Literature review and evidence collection

### 4.1 Search and extraction strategy

The search proceeded through the supplied sources, their full papers and appendices, linked public datasets, and targeted searches for internal laboratory consumption and external usage intensity. Search families included researcher daily inference expenditure, per-user tokens, Codex runtime and concurrency, Claude Code developer costs, Copilot production traces, enterprise telemetry, consumer message intensity, Google internal developer-tool tokens, Meta/xAI employee consumption, usage entitlements, inference-price declines and production energy measurements.

Primary documents were preferred. Secondary pages served as locators or, in the Karpathy case, an explicitly labeled long-post archive. Full OpenAI Codex and consumer PDFs were acquired, and the enterprise and Copilot papers were reviewed in full-text HTML. Anthropic's internal study includes its methods appendix on the same page. The public Copilot dataset card, schema descriptions and release structure were inspected; the approximately 3GB session archives were not downloaded because the release omits user identifiers and cannot answer the person-day question. [S03, S05, S06, S11, S12, S27]

Embedded OpenAI chart specifications exposed numerical values and methodological text omitted from the text-only page view. These values were extracted directly rather than estimated from pixels. Cursor's accessible HTML tables supplied Lorenz curves and token-mix time series. Raster plots in the Codex PDF required approximate digitization for external daily-runtime percentiles.

The source register records publication dates, periods, scope, provenance and limitations. Raw-document hashes are provided where local originals were downloaded. Unknown dates and sample sizes stay unknown. The absence of a usable source for a category is a search result, not proof that no such measurement exists privately or elsewhere.

### 4.2 What each evidence family contributes

| Evidence family | Usable contribution | What it does not establish |
| --- | --- | --- |
| OpenAI internal research [S02] | Daily retail-equivalent quantiles; restricted output estimate; fixed-price time series | Full inference, active-day researcher distribution, internal hardware cost |
| OpenAI Codex paper [S03] | Same-source runtime percentiles and relative growth; concurrency; token shares | Absolute cross-population token levels or FLOPs |
| Claude Code costs [S04] | External active-developer cost benchmark | Known sample, contemporaneous model mix, standardized current-price valuation |
| Consumer ChatGPT paper [S05] | Message aggregate with weekly-user denominator | Free/casual median; input/output/reasoning totals |
| Anthropic internal studies [S06, S17, S33] | Delegation, early model access and changing supervision | Representative employee daily tokens or expenditure |
| Claude Code external sessions [S07] | Words and actions per instruction; agent runtime per week | Reliable conversion to per-user daily tokens |
| Economic Index [S08, S32] | Relative token intensity by artifact and task; aggregate data | Absolute matched person-day ledger |
| Cursor [S09, S10] | Token/spend concentration, caching and concurrency | Absolute daily consumption levels |
| Copilot paper/release [S11, S12] | Detailed call/turn token measurements and cache structure | A reconciled daily user-level token denominator |
| Google internal tooling [S13] | Large organization-wide token consumption | Researcher count and per-researcher intensity |
| Workplace panels/pilots [S14, S15, S27] | Messages or actions per defined licence/activity unit | Inference tokens, hidden reasoning and full monetary equivalence |
| Pricing and energy [S19–S24, S30, S31] | Normalization parameters and comparability constraints | A measured physical-compute access ratio |

### 4.3 Further sources and cohort coverage

The extended search added Jellyfish customer telemetry, Viberank's public submitted-log distributions and aggregate API, a small academic educational-platform study, an early healthcare workshop study, OpenAI Enterprise Signals, developer log audits, SemiAnalysis field interviews and AgentX traces. These add real numerical observations; none supplies a representative matched panel across Karpathy's tiers. Public leaderboard participants' laboratory affiliations are not verified, so they cannot all be classified as non-laboratory employees. [S34-S45]

The student paper's full author-posted PDF was retrieved and checked against its institutional publication record and DOI. The Viberank API was frozen at its reported generation timestamp, October 13 at 07:28:30 UTC. Its current monthly distribution and June article are separate snapshots and populations. AgentX's published schema and statistics were inspected; full 1.85GB trace content was not required to identify the missing person-day denominator. [S37, S38, S45]

### 4.4 Additional laboratory evidence

Google reported internal developer-tool consumption rising from approximately half a trillion tokens/day in March 2026 to more than three trillion/day around the presentation period. That establishes internal scale, but not an individual gap: the active developer denominator, researcher subset and cache/input/output composition are absent. Dividing by a guessed engineering headcount would manufacture an estimate. [S13]

Anthropic's 2025 internal study sampled 200,000 transcripts from February and August and surveyed 132 engineers/researchers. The average maximum consecutive tool-call sequence grew from 9.8 to 21.2, while human turns fell from 6.2 to 4.1 per transcript. It explicitly warns that proportionate sampling supports changes in task mix rather than absolute work volume. The later internal research describes early model access and increased production activity; those are capability and workflow observations, not an inference ledger. [S06, S17]

A nine-agent Anthropic experiment consumed roughly $18,000 over five days and 800 cumulative agent-hours. Its budget includes compute and API calls, including experimental training. The approximately $3,600/project/day arithmetic must not become a researcher-day inference estimate. [S18]

No usable company-published per-researcher inference distribution was identified for Meta AI or xAI. SemiAnalysis reports a Meta employee dashboard with over 60 trillion tokens in 30 days and a highest individual near 280 billion, but the original dashboard, researcher subset, active-user count and token mix are unavailable. That is indirect employee telemetry, not a representative research distribution. [S43] That leaves OpenAI as the only laboratory with a directly usable daily researcher expenditure distribution in this audit. It is not a laboratory-average estimate.

## 5. Data and normalization methodology

### 5.1 Four distinct monetary quantities

**Actual spending** is money paid by a user or organization. **Public API equivalence** is a counterfactual valuation of observed traffic at published rates. **Underlying compute cost** is the provider's hardware, energy and operating resource cost. **Subscription fees** purchase an entitlement bundle. These quantities can differ dramatically and are never substituted for one another here.

For example, an internal employee may incur no personal charge while directing traffic valued at hundreds of public-API dollars. A subscriber may pay a fixed fee while receiving more or less than that fee's worth of API-equivalent traffic. A production company can spend heavily on customer-serving inference without each employee personally using much AI.

The general normalization equation is:

`V = sum_m[(I_uncached*p_input + I_cached*p_cache + I_write*p_write + (O_visible + O_reasoning)*p_output)/1,000,000]`.

This equation assumes that its token components are disjoint. If a provider's reported output already includes hidden reasoning, reasoning is not added again. Some systems treat cache writes within ordinary input rather than as a separate billable component; the schema must reflect that convention. Tool fees, containers, storage and experimental training stay separate.

Two valuations are useful. A **model-specific fixed-date valuation** reprices each observed model's actual traffic at one date. A **single-reference-model valuation** answers what the same token counts would cost under one chosen price schedule. The latter is a workload-size index, not proof that the reference model can perform the same task at equal quality. Neither can be calculated exactly from a mixed dollar total with no model/token composition.

### 5.2 Time and activity denominators

A person-day mean requires the numerator and denominator to describe the same people, dates and scope. A user active at least once during a week contributes seven calendar days to a weekly-active-account/calendar-day statistic; that does not turn the result into a daily-active-user mean.

For a matched panel, calendar-day means can be decomposed into activity prevalence times conditional active-day means. Public averages over separately defined user cohorts may not satisfy that identity directly. Percentiles are more difficult: adding inactive users can change the median discontinuously, and a median must not simply be divided by an active fraction.

Weekly averages of daily medians are also different from the median of all user-days or the median of each person's weekly average. This distinction applies directly to the OpenAI expenditure charts. Reported internal “human workdays” are a scale denominator, not a measurement of actual employee hours worked.

### 5.3 Common reference period and prices

No common measurement week is available for all populations. The internal expenditure series ends in mid-August 2026; the same-source runtime comparison ends June 11; the external cost benchmark is undated; the consumer aggregate is July 2025. Consequently, this report does not claim an October 13 synchronized cross-population estimate.

OpenAI's expenditure data are already priced at September 3, 2026 retail rates, with internal or pre-deployment models mapped to nearest production counterparts and processing tiers chosen to resemble internal deployment. The external Claude Code benchmark does not provide enough detail to reproduce that basis. Its $13 figure cannot be exactly repriced to September 3 or October 13. [S02, S04]

The consumer scenarios use an October 13 snapshot of standard Sonnet 5.5 pricing: $2/million uncached input, $0.10/million cache reads, $2.50/million five-minute cache writes and $10/million output. These are current documentation values; launch communications can show different earlier cache rates. The script also evaluates Haiku, Opus and Fable price schedules without pretending their capabilities are equivalent. [S19]

### 5.4 Observation classification and missing values

The ledger distinguishes observed provider statistics, provider estimates, digitized approximations, self-reports, derived estimates and author assumptions. A provider-derived API valuation counts as an observed usage-valued statistic, not an observed cash transaction. Original values, source relations such as “greater than,” and published statistics remain separate from derived calculations.

Missing daily input or reasoning values are blank. A zero appears only when actually reported or operationally defined. Unknown quantities never become zero to complete a chart. Confidence labels describe confidence in interpretation and usefulness, not a probability that a conclusion is correct.

## 6. Quantitative results

### 6.1 Internal expenditure: the strongest daily researcher benchmark

Direct chart extraction yields **$601.253/day at P50** and **$7,047.126/day at P90** for the final plotted week ending August 15. The population includes zero-usage research employees. Daily quantiles are averaged within Monday–Sunday weeks, excluding company holidays; the final week is partial. Interactive coding-agent surfaces are covered, while programmatic automation is excluded. These are public-API-equivalent valuations, not internal accounting costs. [S02]

The same-source P90/P50 quotient is **11.72**. It is justified by recovered chart values; dividing the article's two verbal lower thresholds alone would not establish that quotient. Exact machine precision is retained in the data, but two significant digits are sufficient for interpretation.

### 6.2 External developer expenditure and comparison

Anthropic's current enterprise benchmark is approximately $13 per developer per active day and $150–250 per month, with 90% below $30 per active day. The monthly band implies roughly 12–19 active days at the daily mean if interpreted as the same cohort, but the averaging scheme is not documented, so no automatic conversion is made. [S04]

| Expenditure comparison | Arithmetic | Interpretation |
| --- | --- | --- |
| Internal researcher P50 / external developer mean | 601.253 / 13 = **46.25** | Most useful available cross-source benchmark quotient; statistics and price bases differ |
| Internal researcher P90 / external 90%-below threshold | 7,047.126 / 30 = **234.90** | Threshold quotient; would exceed about 235 against an external P90 below $30 only under compatible definitions |
| Internal researcher P90 / internal P50 | 7,047.126 / 601.253 = **11.72** | Same-source expenditure inequality |

The first quotient is not a median-to-median gap. The second is not an exactly measured cross-population P90 ratio: one numerator is a weekly mean of daily quantiles, and the external statement describes an unspecified user-cost distribution. Approximate source values do not justify strict statistical bounds or confidence intervals.

For illustration, if an external mean of exactly $13 described the same nonnegative user-level variable whose median was sought, that median could not exceed $26. This distribution-free mean/median bound would imply at least approximately 23× against the internal P50 under fully matched accounting. Those matching conditions are not established, so this remains a conditional mathematical result rather than a headline empirical bound.

![Figure 1: source-valued expenditure and consumer scenarios](figures/figure_1_expenditure_gap.png)

**Figure 1.** Solid points show source-valued consumption benchmarks; hollow points show assumptions or an unaudited case. The consumer band is an illustrative scenario set. Different source-defined days and price schedules remain visible. Zero deliberate non-user consumption sits outside a logarithmic axis. Sources: S02, S04, S05, S19, S26.

### 6.2a Additional external expenditure distributions

Jellyfish's Q1 study reports monthly developer token P50 51 million and P90 380 million, and Claude-price-equivalent monthly expenditure P50 $52.38, P75 $226.58 and P90 $691.14. The sample is 12,000 developers at 200 companies; active days, model mix, exact pricing date and zero-use rules are not disclosed. [S34]

Viberank's June report covers 792 submitting developers and 29,230 tracked coding user-days. Daily API-equivalent P50/P90/P99 are $29/$215/$708. The board retains the largest submitted window per developer. The October API snapshot instead has 1,220 developers in a 30-day-normalized distribution: P50 $1,520.93, P90 $8,625.00 and P99 $41,533.26. Dividing those by 30 gives rates $50.70/$287.50/$1,384.44, **not daily quantiles**. [S36, S37]

| Internal / external benchmark | External denominator | Quotient | Interpretation |
| --- | --- | --- | --- |
| OpenAI P50 / Viberank June P50 | $29/coding day | **20.7x** | Daily source-valued medians; activity, selection, dates and prices differ |
| OpenAI P90 / Viberank June P90 | $215/coding day | **32.8x** | Corresponding daily quantile labels, different accounting and populations |
| OpenAI P50 / Viberank October monthly P50 /30 | $50.70/day rate | **11.9x** | Daily quantile average vs normalized-window rate quantile |
| OpenAI P50 / Jellyfish monthly P50 /30 | $1.746/day rate | **344x** | Calendar-rate arithmetic; monthly P50 is not daily P50 |
| OpenAI P90 / Jellyfish monthly P90 /30 | $23.04/day rate | **306x** | Same limitation; historical source prices cannot be exactly aligned |

These are alternative benchmark calculations, not bounds on one estimand. Self-selection, choosing the largest window, employer funding, multiple tools, task mix and sampling of company customers can move the denominator dramatically. A public article should show these alternatives alongside the earlier 46.3x P50/mean quotient rather than choosing whichever best fits a narrative. [S02, S04, S34, S36, S37]

### 6.3 Same-source agent-runtime comparison

The Codex paper's daily-runtime measure excludes inactive accounts and gaps longer than 30 minutes, sums overlapping turns, and assigns turns to their starting calendar day. It includes model response latency, tool execution and shorter gaps. It excludes noninteractive batch use. It is therefore a useful agent-workload measure but not accelerator utilization. [S03]

| Percentile | OpenAI employees | External organizational accounts | External individual accounts |
| --- | --- | --- | --- |
| P50 | 2.5h [2.2–2.8] | ~0.42h [0.32–0.52] | ~0.55h [0.45–0.65] |
| P90 | ~17.5h [16.5–18.5] | ~2.45h [2.2–2.7] | ~3.1h [2.8–3.4] |
| P99 | ~71h [68–74] | ~12.4h [11.9–12.9] | ~15.5h [14.8–16.2] |

**Units:** cumulative agent-hours per daily active account, June 11, 2026 endpoint. Brackets are conservative visual extraction tolerances, not statistical confidence intervals. OpenAI's 2.5h and approximately 71h are also reported in text. Other readings come from Figure 10; the raster panels and pixel calibration are recorded in the digitization protocol.

| Matched-percentile runtime quotient | Central reading | Extraction range |
| --- | --- | --- |
| OpenAI / external organizational P50 | 5.95× | 4.23–8.75× |
| OpenAI / external individual P50 | 4.55× | 3.38–6.22× |
| OpenAI / external organizational P90 | 7.14× | 6.11–8.41× |
| OpenAI / external individual P90 | 5.65× | 4.85–6.61× |
| OpenAI / external organizational P99 | 5.73× | 5.27–6.22× |
| OpenAI / external individual P99 | 4.58× | 4.20–5.00× |

The upper-tail comparison is not orders of magnitude. This is meaningful counterevidence to any claim that every reasonable activity metric must show a thousand-fold insider gap. It does not contradict the expenditure benchmark because runtime can contain very different inference intensity and valuation per hour. The populations also differ: all internal employees here, research employees in the expenditure series.

### 6.4 Absolute daily tokens: new external benchmarks, no matched distribution

The OpenAI taxonomy chart ends at **722,833 output tokens/research employee/day**. It extrapolates from 2% of internal sessions, caps each sampled user's daily total at the P95 among nonzero sampled users, excludes grading and unmatched research tasks, and smooths over 14 days. It is a restricted, winsorized mean estimate, not a median, complete output total, or clean active-day statistic. Input and separately counted reasoning are unavailable. [S02]

It cannot be combined with the $601 expenditure median to infer an average token price: the numerators have different statistical and coverage definitions. Nor can it be compared directly with a per-turn external median.

Viberank reports approximately 2.5 trillion processed tokens and 5.9 billion output tokens over its 29,230 coding user-days. Dividing matching aggregates gives **~85.5 million total** and **~202,000 output tokens/coding day**. The 94.8% cache-read share explains much of the huge processed-token count. The restricted internal output estimate divided by this external mean is **~3.6x**. This is a useful heterogeneous output benchmark, not a matched researcher/professional ratio: internal winsorization, calendar versus active coding days, dates, reasoning coverage and selection differ. [S02, S36]

The academic study invited 461 undergraduate statistics students; 43 registered and six single-prompt users were excluded. The analysis includes 37 users and 781 prompts, July 8-24, 2025, on one optional platform. Tracker/no-tracker groups have 375/406 prompts, 21/16 users, mean inputs 7,427.1/13,468 and mean outputs 740.2/873.3 tokens per prompt. Reconstructing totals and dividing by **37 x 17 calendar days** yields **~13,121 input and ~1,005 output tokens/student/day**. Zero-use days within this selected panel are included; other platforms are untracked. [S38]

The reconstruction is `(375*740.2 + 406*873.3)/(37*17)` for output. The paper's Figure 5 averages token lengths within daily observations; it is not substituted for summed daily consumption. Its per-prompt confidence intervals cannot become daily-mean confidence intervals without person-level data. The internal restricted-output quotient is **~719x** against this educational-platform mean, **not against casual consumers**. At the fixed Sonnet reference prices, the reconstructed student workload values to **$0.0363/calendar day**; that is a workload-price index, not its actual bill or identical model capability. [S02, S19, S38]

![Figure 2: heterogeneous daily token benchmarks](figures/figure_2_daily_tokens.png)

**Figure 2.** Daily input/output benchmarks are derived only where matching aggregate denominators exist. The total-token panel separately shows Jellyfish monthly quantiles /30 and Viberank's active coding-day mean. The casual-user median remains missing; no internal input total is inferred. Sources: S02, S34, S36, S38.

The early healthcare workshop provides a different 2023 anchor: mean inputs 1,830 and outputs 274 tokens over 949 analyzable prompts, with 24 prompts/user/event and total GPT spending below $300 across all resources. Half the prompt text was lost and the resource/user coverage differs. Multiplying its per-prompt token means by an unmatched prompts/user mean would create an assumption, not measured individual consumption. It cannot establish a 2023-2026 gap trend. [S39]

### 6.5 Copilot: valuable token telemetry with unresolved consistency problems

The Copilot paper's abstract reports 95 trillion tokens. Table 3 reports 44.9 trillion prompt tokens and 39.3 billion completion tokens, approximately 44.94 trillion combined. It lists 760.5 million calls and 95.1 million turns. Those aggregate completions imply approximately **51.7 tokens/call** and **413 tokens/turn**, whereas the paper gives a **247-token per-call median** and a **4,000-token per-turn mean** elsewhere. [S11]

Under a common nonnegative per-call population, a mean below half the median is impossible. Different samples or coverage could reconcile some quantities, but the paper does not expose sufficient linkage to do so. These comparisons are recorded as unresolved scope/reporting conflicts, not evidence of a known correction.

Mechanical division of Table 3 by 3.2 million users and seven days would produce approximately **2.00 million prompt tokens** and **1,754 completion tokens per weekly-observed user/calendar day**. The abstract total instead implies approximately **4.24 million total tokens/day**. These derivations are explicitly quarantined and excluded from headline token-gap ratios.

The public release has 301,026 non-enterprise sessions, 631.4 billion prompt tokens, 540.95 billion cached prompt tokens and 4.91 billion completions. It has no user/account identifiers and anonymizes models. Its session-level totals cannot repair a person-day denominator or identify model-specific prices. Cached tokens are a subset of prompt tokens; adding them to prompt totals would double-count. [S12]

### 6.6 Consumer measurements and bounded scenarios

The consumer paper's rounded July 2025 anchors, 18 billion messages/week and 700 million weekly users, imply **25.7 messages/week**, or **3.67 messages per weekly-active account/calendar day**. These include Free, Plus and Pro accounts. They do not identify casual users, daily active usage or a median. The separately rounded greater-than-2.5-billion/day statement is not treated as an independent matched denominator. [S05]

A contemporary workplace panel reports 93 messages per monthly active user in September 2026, equivalent to **3.10/monthly-active-user/calendar day**. Its reported 251 characters/message describes typed user text, not complete model input. The same panel includes files and skills, so prompt text alone could substantially undercount inference. The DBT pilot instead reports 72 actions/licence across 63 working days, approximately 1.14/licence/working day, including non-use and absences. Neither is a token measurement. [S14, S15]

The youth keystroke study records a median six messages per observed app-day and a mean 44.52, illustrating the importance of distributional skew. Its monitored children, app mix and unobserved assistant responses prevent using it as an adult casual-user inference denominator. [S28]

The following calculation uses the consumer message aggregate only as an anchor. **All token lengths, reasoning amounts and workload labels below are assumptions.** They are not fitted to consumer telemetry. Every row uses the same current Sonnet 5.5 price schedule, with no caching, tool charges or multimodal calls.

| Assumed workload per user message | Input | Visible output | Hidden reasoning | API value/WAU/calendar day | Internal P50 / scenario |
| --- | --- | --- | --- | --- | --- |
| Short | 500 | 150 | 0 | $0.00918 | ~65,470× |
| Routine | 2,000 | 500 | 0 | $0.0331 | ~18,186× |
| Long | 20,000 | 5,000 | 0 | $0.331 | ~1,819× |
| Reasoning-heavy | 20,000 | 5,000 | 45,000 | $1.98 | ~303× |

The enormous range is the finding: missing workload structure dominates the result. A more expensive model, longer hidden reasoning or larger tool-input context can shrink a dollar quotient dramatically; cheaper models can enlarge it without changing task accomplishment. The script exposes all assumptions and a multi-model price grid. It does not call these rows the casual-user median.

Conditional external-mean/scenario quotients are approximately 1,416×, 393×, 39× and 6.55×. Conditional internal-P90/scenario quotients are approximately 767,354×, 213,154×, 21,315× and 3,553×. They are arithmetic scenarios with mismatched dates and populations. **They do not answer the requested P90-researcher/median-casual-user empirical comparison.** No finite evidence-based interval for that ratio is identified.

## 7. Within-population inequality

![Figure 3A: inference expenditure distributions](figures/figure_3_expenditure_inequality.png)

**Figure 3A.** Source-reported daily expenditure distributions and normalized monthly distributions occupy separate panels. Missing P99 values remain absent. Viberank's daily P90/P50 is approximately **7.41x**, P99/P50 **24.4x**; Jellyfish monthly P90/P50 is **13.2x**. The October selected-window distribution has P90/P50 **5.67x** and P99/P50 **27.3x**. These within-source quotients are better defined than cross-source comparisons, but do not generalize to all developers. Sources: S34, S36, S37.

![Figure 3B: daily agent-runtime distributions](figures/figure_3_runtime_inequality.png)

**Figure 3B.** Matched runtime percentiles from the same product and period provide a more coherent comparison than mixed dollar valuations. Extraction tolerances remain distinct from confidence intervals. Source: S03.

At the research expenditure endpoint, the ratio of weekly mean daily P90 to P50 is 11.72; a P99 dollar value is not published. Anthropic's external developer benchmark has a mean and a 90%-below threshold but no median or P99; the additional sources provide their own distinct distributions. It cannot be completed by assuming a distribution.

Cursor's accessible Lorenz table reports token Gini **0.72** and spend Gini **0.75**. The bottom half accounts for **5.15% of tokens**; the top tenth accounts for **55.87%** in that report's table. A separate September article says the top tenth accounts for nearly two-thirds over its preceding four-week window. These differ in period/cohort and are preserved as distinct observations. The 20-bin linear approximation gives a token Gini of approximately **0.707**, below the reported coefficient because within-bin inequality is not recoverable. [S09, S10]

![Figure 6: external Cursor token and spend concentration](figures/figure_6_cursor_lorenz.png)

**Figure 6.** External advanced users already exhibit substantial internal inequality. Cumulative shares do not identify P90/P50 token levels. Source: S09.

Concentration matters for comparisons. A platform-wide mean can be much higher than its median, while a cohort selected for coding agents can be much more intensive than its wider consumer base. Selecting only users who operate agents or have employer funding changes both the denominator and the interpretation of “advanced user.”

## 8. Evolution over time: what can and cannot be inferred

![Figure 4: fixed-price internal expenditure evolution](figures/figure_4_evolution.png)

**Figure 4.** The internal fixed-price series and an external enterprise inequality series are plotted in separate panels. The latter has published January/June endpoints, with firms re-ranked each month. No artificial 2023-2025 all-tier series is spliced in. Sources: S02, S40.

The internal expenditure P50 rose from approximately **$5.66/day** in the week ending March 1 to **$601.25/day** by August 15, approximately **106×**. From June 14's approximately **$161.09/day**, the increase was approximately **3.73×**. This is growth in a fixed-price workload valuation, though evolving coverage, internal model mappings and researcher composition may also contribute. [S02; derived calculations]

In the same Codex paper, P99 daily runtime grew approximately **88%** internally, **25%** in external organizations and **50%** among individual accounts from April to June. If compared on the same endpoints, the internal/external runtime ratio increased by **1.88/1.25 = 1.50×** against organizations and **1.88/1.50 = 1.25×** against individuals. This supports widening at the upper runtime tail over that window, not a general 2023–2026 compute-gap trend. [S03; derived calculations]

External intensity also rises. The enterprise paper reports approximately sevenfold aggregate output growth from June 2025 to March 2026 and approximately fourfold in a consistent firm cohort. Those are organization aggregates, not per-person changes. Anthropic's extreme per-turn duration rose from below 25 to above 45 minutes between October and January while its median stayed around 45 seconds. Growth can concentrate in the tail even when typical interactions barely change. [S27, S33]

OpenAI Enterprise Signals reports the ratio of output tokens per active user at top-decile firms versus middle-decile firms rising from **2.6x in January to 8.3x in June**, a **3.19x increase in that ratio**. This measures external enterprise intensity inequality, not laboratory advantage. Monthly re-ranking can change membership; the source does not give absolute daily levels or a fixed firm panel. The firms reportedly have the same frontier models, supporting a workflow/adoption mechanism distinct from exclusive model access. [S40]

Jellyfish's later review also describes divergence in weekly Claude Code tokens: P90 roughly 50 million to 170 million while typical usage remained flatter. Its company-level cost and release tables describe different aggregates; they cannot be joined to the internal series to estimate a laboratory/external gap. The appendix's Tokens/User column has no explicit time denominator, so those printed values are preserved without a daily token conversion. [S35]

Financial spending can move differently. Ramp revised its top-1%-firm July monthly AI spend per employee to $7,976, then reported $7,205 in August, a decline of approximately 9.7%. It also reported a fall in an effective token-price index from $1.15 to $0.68. Those are firm financial measures that include subscriptions and customer-serving workloads; they neither prove reduced employee inference nor provide a clean internal/external comparison. [S25]

The evidence therefore supports rapid internal growth and short-window runtime and external-enterprise widening results. It does not establish a continuous monotonic increase in access inequality from 2023 through 2026.

## 9. Capability access, permitted capacity and consumption

![Figure 5: multidimensional access comparison](figures/figure_5_capability_matrix.png)

**Figure 5.** The matrix uses qualitative, supplier-specific properties. There is no invented capability score or universal frontier-employee entitlement. Sources: S03, S17, S21–S23.

Public premium users and API professionals can access strong models, tools, code execution and concurrent agents. Paid capacity is not automatically a distinct model-quality tier. For example, current Gemini documentation lists its model classes across free and paid plans while differentiating quotas, reasoning modes and context: free 32k, AI Plus 128k, and Pro/Ultra one million tokens. Its usage multipliers range from 2× and 4× relative to standard limits to Ultra tiers at 5× or 20× Pro limits. These are entitlements, not measured token or FLOP ratios. [S22]

Current Codex documentation gives task-dependent Plus estimates of 5–45 Astra local messages per five hours, 15–160 Sol messages, or 350–3,000 Luna messages. Those estimates are not fixed token caps. Pro currently lacks a five-hour limit, but weekly allowances, model choice, processing modes and additional credits matter. Claude Code and Claude share five-hour and weekly allowances, with a separate Fable weekly cap on Max. Such live rules are snapshots, not durable measurement constants. [S21, S23]

The June Codex paper states that internal OpenAI usage has no quantity restriction. That is strong evidence of different incentives and permitted access, but not an assertion of unlimited physical capacity, unrestricted security permissions or equal access to every checkpoint. Anthropic documents internal access to unreleased models. Whether the resulting quality advantage exceeds the token or monetary gap cannot be reduced to a scalar without matched tasks, tools and budgets. [S03, S17]

External organizational budgets are heterogeneous. SemiAnalysis's convenience interviews with more than 50 enterprises report hard monthly allowances of $250 and $500 at two unnamed firms, about $2,000 at Workday/Stripe, and soft allowances of $800 for junior and $1,600-4,000 for senior cybersecurity staff. Accounting and coverage are insufficiently specified for API-equivalent normalization; soft allowances are not hard ceilings. The publisher also self-reports a few employees consuming four to five figures of dollars/day without limits. That is an unaudited organizational case, not a representative statistic. [S43]

Jellyfish's separate 30-day concurrency study reports 84% of users peaking at one or two active sessions, 11.4% at three and 4.7% at four or more (rounded shares). Only 6.1% of aggregate active time was concurrent. Internal subagents and other providers are invisible. These measured workflow patterns qualify any assumption that advanced external users routinely run large parallel fleets. [S41]

For maximum autonomous duration, parallelism and organizational accelerator allocation, no universal per-person ceilings were found. A day's summed runtime exceeding 24 hours proves overlap, not the existence of a single 71-hour unattended task. Similarly, observed concurrent agents establish use, not the maximum allowed count.

## 10. Physical compute, accelerator-hours and energy

### 10.1 Why token counts are insufficient

Equal numbers of tokens can imply different computation. A rough parameter-matrix approximation is **F ≈ 2 × active parameters × freshly executed tokens**, before attention, routing, multimodal encoders and other operations. It must distinguish fresh prefill, generated decode, and reused cached prefixes. Cached input is still relevant to memory and decode attention, even when its prefill projections are reused.

DeepSeek-V3 illustrates the architecture issue: it has 671 billion total parameters but 37 billion active per token. Treating its total count as executed parameters would inflate the main parameter term by approximately **18.1×**. Its published architecture is useful for an openly specified inference calculation; it does not tell us which architectures the consumer or internal laboratory traffic used. [S31; derived ratio]

Closed-model active parameters, hidden reasoning, speculative proposals and rejected tokens are mostly absent from the population evidence. Reasoning can increase executed decode substantially even when visible answers are short. Model tokenizers differ; Anthropic's current documentation notes newer tokenizer conventions, so text-equivalent token comparisons can also shift without proportional compute changes. [S19]

### 10.1a A reproducible cache-aware reference valuation

Viberank's June aggregate mix is 94.8% cache reads, 4.2% writes, 0.8% uncached input and 0.2% output. At 85.5 million processed tokens/coding day, the same workload valued at current standard Sonnet rates is **~$20.17/day**. Incorrectly treating cached input and writes as ordinary uncached input produces **~$172.43/day**, approximately **8.55x** as much. These are mean-workload reference-model scenarios; they are not the reported $29 daily median or actual invoices. The rounded 0.2% output share implies a slightly different output total from the separately reported 5.9 billion, so those two representations are not silently combined. [S19, S36]

![Figure 7: cache-aware reference valuation](figures/figure_7_cache_accounting.png)

**Figure 7.** One measured rounded aggregate mix, valued under four explicit public price schedules. Model capability is not assumed equivalent. The comparison isolates accounting errors; it does not convert cached tokens into FLOPs. Sources: S19, S36.

A one-developer log audit reports 91,086 calls across Claude Code and Codex, $15,656.63 of priced inference, and 503 million unpriced Codex tokens. It demonstrates repeated streamed records overstating tokens by 124.3% under a naive parser. The author's open parser provides useful counting rules, but private logs were not independently audited, Codex cache writes are absent, and the page label precedes one day of its stated logs. It remains a self-reported case rather than a population benchmark. [S42]

AgentX contributes an open trace path to better hardware normalization. Its released subset has 393 filtered sessions, 98,827 requests, roughly 21.6 billion reconstructed input tokens and 106.5 million outputs. Input is a 64-token KV-block proxy, not exact tokenizer counts; the card documents drift up to approximately 260,000 tokens in heavy-cache-write tails. Person identities and absolute observation-day denominators are absent. Replaying these traces on open models can estimate **that replay's** accelerator resources, not recover the original closed-model compute or per-researcher use. [S44, S45]

### 10.2 Why agent-hours are not accelerator-hours

An agent can wait for tools, run CPU code, share a batched accelerator service, or perform many model calls. Accelerator-hours require the allocated accelerator count and the time/occupancy attributable to each request, with a stated convention for idle capacity. Multiplying agent wall-clock time by a guessed GPU count would overstate precision. Allocated GPU-hours and useful executed FLOPs are themselves different measurements.

No reliable researcher/casual, researcher/professional or P90/median ratio in inference FLOPs or accelerator-hours is computed. The inputs required for such an estimate are missing. Even a published training-GPU allocation chart cannot fill that gap: training and inference are different workloads.

### 10.3 Energy is measurable but not a universal conversion factor

Google's production measurement estimates **0.24Wh** for the median Gemini Apps text prompt under a comprehensive boundary, compared with **0.10Wh** under an active-accelerator-only boundary. The full method includes host systems, idle capacity and data-center overhead; the corresponding [technical paper](https://arxiv.org/html/2508.15734v1) provides the measurement framework. [S30]

Energy is a valuable resource measure, but a median prompt-energy figure cannot be multiplied by a mean message count to obtain a defensible mean daily energy total. The model mix, length distribution, batching and measurement period must match. It also cannot be applied to long-running internal research agents as if all prompts were equal. No cross-population daily energy ratio is identified here.

## 11. Uncertainty, sensitivity and bias

### 11.1 What the ranges mean

| Result family | Numerical uncertainty supplied | Confidence in interpretation |
| --- | --- | --- |
| Internal expenditure endpoints | Original embedded precision; sampling CI not disclosed | High for source definition and extracted values; generalization limited |
| External developer cost | Approximate vendor figures; unknown sampling error | Medium for existence of benchmark; lower for normalization |
| Runtime ratios | Conservative digitization tolerances propagated by interval division | Medium; same source and period, no statistical CI |
| Consumer monetary scenarios | Explicit token/reasoning/price assumptions | Correct conditional arithmetic; low empirical identification |
| Restricted internal output | Source extrapolation, winsorization and classification uncertainty | Medium; no standard error exposed |
| Copilot daily token derivations | Conflicting totals retained | Low; quarantined |
| External one-person cases | Self-report; no independent private-log audit | Low; not representative |
| Jellyfish distributions | Source sample known; no raw token mix/activity distribution or quantile CI | Medium for source-valued monthly benchmarks |
| Viberank distributions | Highest-window and voluntary-submission bias; no sampling CI | Medium for submitted cohort; low generalization |
| Student daily reconstruction | Rounded prompt means; selected cohort and one platform | Medium for calendar arithmetic; low population generalization |

No statistical confidence intervals for the access-gap estimates are calculated. Large source sample counts do not supply missing microdata, cluster structure or sampling uncertainty. The source studies contain confidence intervals for other outcomes, but those cannot be transferred to a different ratio. The student source reports a 95% Wald interval for its modeled per-prompt completion mean; it is retained as a source-specific statistical estimate, not an access-gap interval. A bootstrap would require matched person-day panels; correlated tasks and repeated users should be resampled at an appropriate person or organizational cluster level.

### 11.2 Expenditure sensitivity without false confidence

The baseline cross-source quotient is 46.25. A deliberately hypothetical sensitivity grid varies each source's valuation multiplier from 0.5 to 2 and an external activity fraction from 0.5 to 1. The resulting calendar-alignment/price quotient spans approximately **11.6–370×**. This grid is not a probability model, not an empirical credible interval, and not a claim that those multipliers encompass reality. It shows how missing repricing and day definitions affect interpretation.

Internal percentiles are left as reported. They are not divided by activity fractions, because conditioning a quantile cannot be recovered by linear scaling. The separate sensitivity table documents every combination rather than presenting one opaque uncertainty bar.

For consumer comparisons, no evidence-based lower or upper token budget is recovered from the message aggregate. More hidden reasoning or unobserved tool input could materially increase consumption. The scenario span must not be promoted to a formal bound or a casual-user confidence interval.

### 11.3 Selection and measurement risks

Laboratory staff have technical familiarity, organizational support, internal integrations and employer-funded usage. External coding-agent users are selected for both workflow opportunity and engagement. Consumer accounts include professionals and heavy paid users. A selected founder's automated fleet is not a typical advanced user. These differences cannot be controlled with published aggregates.

Within a laboratory, research support staff, engineers and nontechnical employees can have different task mixes and permissions. The internal researcher expenditure distribution must not be applied to all employees or to all frontier laboratories. Equally, the most intensive public users must not be hidden by a low aggregate mean. Viberank selection operates twice: people volunteer and each person contributes their highest-cost window. A verified GitHub identity does not audit the local logs or establish non-laboratory employment. Its 645 global active dates are not 645 summed user-days and cannot normalize the global token total. [S37]

Coverage matters in both directions. Internal telemetry excludes some programmatic automation; consumer interfaces can invoke hidden tools and context. Agent runtime can miss long pauses or assign cross-midnight work to its starting day. Successive requests can repeatedly count cached context. Price changes can reduce expenditures while activity rises. These mechanisms prevent interpreting one scalar as a complete production-capability gap.

## 12. Hypotheses, implications and counterarguments

| Hypothesis | Empirical assessment | Interpretation and remaining speculation |
| --- | --- | --- |
| A. Ordinary/researcher consumption gap spans orders of magnitude | Not identified for physical compute or casual-user distributions | A selected educational output benchmark yields ~719x; selected coding-user output yields ~3.6x. Neither identifies casual-user compute |
| B. Insider/external-professional gap is the largest tier gap | Not established | Insider expenditure benchmarks are much higher; free/premium entitlement differences can also be large, and extreme external use overlaps internal use |
| C. Autonomous parallel agents are widening consumption inequality | Partial support | Same-source P99 runtime and external enterprise intensity ratios widened in 2026; external session concurrency remains limited. No full 2023-2026 ratio series |
| D. Capability gap exceeds token/compute measurements | Qualitative mechanism documented; magnitude unknown | Early models and internal environments can matter; comparison requires matched task performance at matched resource budgets |
| E. AI access drives growing inequality in research/production | Plausible mechanism; causal effect not quantified | More inference can expand feasible work, but task choice, verification, skills and infrastructure also determine outcomes |

The external Larry Labs case reports approximately $130,000 in list-equivalent inference over 30 days for one operator across two machines, including subagents, retries and failed runs. That implies approximately **$4,333/day**, well above the OpenAI research median benchmark. It is unaudited and covers a broader workload scope, so it cannot overturn a representative comparison. It nevertheless cautions against treating employee status as an absolute upper/lower ordering of possible inference consumption. [S26]

Falling prices can diffuse access. Epoch's benchmark-conditioned analysis finds price declines ranging from roughly ninefold to 900-fold/year across particular historical milestones; these are not moving-frontier guarantees. Better small/open-weight models can also reduce resource requirements for fixed tasks. Owning weights changes availability and control, while hardware, engineering time and evaluation remain real costs. [S24, S31]

Agent diffusion can narrow some gaps even as parallelism enlarges others. Internal advantage may come partly from workflow integration, confidence and a reservoir of difficult tasks, rather than exclusive model capability alone. The useful empirical question is how much of a performance advantage remains after matching model, task, inference budget, tool permissions and domain knowledge.

More output does not automatically produce more valuable research. The enterprise study's covariate-adjusted associations do not identify a causal productivity effect from tokens, and self-reported laboratory productivity is subject to selection and expectation bias. Verification can become the bottleneck. A public article should avoid translating a token or expenditure ratio into an equal ratio of scientific capability, income or productivity. [S17, S27]

## 13. Conclusions and publication recommendations

The public evidence supports substantial but strongly cohort-dependent differences in **usage-valued expenditure**. Selected coding-day medians give an approximately **21-fold** internal/public-user benchmark, while other source choices produce very different quotients. Restricted output benchmarks span approximately **3.6-fold** against submitted coding-day means and **719-fold** against one educational calendar-day panel. These are distinct comparisons, not a range for a universal gap. The same-product Codex runtime differences are approximately **4.5-7.1-fold**. It does not yet identify a casual-user token or physical-compute denominator, a universal laboratory employee distribution, or a scalar model-quality gap.

The defensible article formulation is:

> OpenAI values its median researcher's daily coding-agent inference at about $600. A selected public coding-user dataset reports a $29 median day, implying a roughly 21-fold cross-source expenditure benchmark. Other company and heavy-user datasets give substantially different comparisons. Same-product runtime gaps are roughly five to sevenfold. The physical-compute gap to casual consumers remains unmeasured.

This is a research finding, not an absence of findings. It identifies the best available numerical contrasts and the precise reason a more dramatic universal multiplier would exceed the evidence.

For a stronger follow-up, laboratories and vendors should release aggregated matched-week person-day distributions, separately for zero-inclusive and daily-active populations. They should publish input, cache reads/writes, visible output and hidden reasoning by model/version and processing tier, alongside an attribution policy for subagents, batch jobs and research experiments. Counts of users, days, sampled calls and coverage should accompany P50/P90/P99 and uncertainty estimates. Physical-compute estimates require model architecture or direct hardware telemetry. A small consented external panel would be useful, but cannot replace representative casual-user data.

## Appendix A. Reproduction and evidence audit

Run `python analysis.py` after installing the packages listed in `requirements.txt`. The script reads frozen numerical inputs, computes all normalization and scenario tables, regenerates eight figures as PNG/SVG, and writes `data/results.json`. It requires no credentials or network. Original evidence values are never overwritten. The report renderer is separate: `python render_report.py` generates the report PDF and one-page summary PDF from the supplied Markdown and figure files.

The extension in `extended_analysis.py` is invoked by `analysis.py`; it adds student aggregate reconstructions, additional expenditure benchmarks, cache-aware pricing and enterprise intensity trends. The principal calculated tables are `comparisons.csv`, `normalized_observations.csv`, `consumer_scenarios.csv`, `expenditure_sensitivity.csv`, `requested_ratio_identification.csv` and `source_consistency_checks.csv`. Quarantined Copilot arithmetic is isolated in its own file. Original numeric chart/table snapshots preserve extraction provenance; SVG labels remain editable text.

`evidence_dataset.csv` contains one row per extracted usable observation, including source URL, publication date, measurement period, population, sample size when known, metric/unit, original reported value, numeric value and relation, statistic, consumption/capacity classification, evidence type, limitations and interpretation confidence. Normalized and scenario estimates are separate tables linked by source IDs. Thousands of time points do not constitute thousands of independent measurements of the access gap.

The research reviewed primary text, metadata and public numeric summaries. It did not obtain proprietary employee logs, reconstruct missing model architecture, audit subscription valuations, or access private accounts. The full initial Karpathy long-post wording remains partially unverified. No speculative values are inserted into missing-data cells.

## Appendix B. Requested comparisons and identification status

| Comparison | Daily output/total tokens | Standardized API equivalent | FLOPs |
| --- | --- | --- | --- |
| Frontier researcher / casual user | Not identified | Consumer workload scenarios only | Not identified |
| Frontier researcher / advanced professional | ~3.6x restricted-output/submitted coding-day mean benchmark; no matched full distribution | ~21x source daily-median benchmark; 46.3x P50/mean and other monthly-rate comparisons; exact repricing unavailable | Not identified |
| Advanced professional / casual user | Not identified | Conditional external-mean/scenario arithmetic only | Not identified |
| P90 frontier researcher / median casual user | Not identified | Casual median missing; no empirical ratio | Not identified |

The closest coherent alternative is internal employee/external Codex runtime at matched percentiles and one date. It measures agent workload and cannot be relabeled inference compute.

## References

The source register below lists direct source links. All were accessed on October 13, 2026. Undated snapshots and partially verified records are explicitly marked.

- **[S01]** Andrej Karpathy. [Karpathy AI capability funnel (edited X post)](https://x.com/karpathy/status/2109361546505966046). 2026-10-11. Measurement period: Not specified.

- **[S02]** OpenAI. [Research acceleration: The view inside OpenAI](https://openai.com/index/research-acceleration-view-inside-openai/). 2026-09-06. Measurement period: 2026-01-01 to 2026-08-15/16.

- **[S03]** Johnston, Holtz, Richmond, Ong, Tambe, Chatterji / OpenAI. [The Shift to Agentic AI: Evidence from Codex](https://arxiv.org/abs/2606.26959v1). 2026-06-25. Measurement period: 2025-08 to 2026-06-11; runtime 2026-04-07 to 2026-06-11.

- **[S04]** Anthropic. [Manage costs effectively](https://code.claude.com/docs/en/costs). Undated live documentation. Measurement period: Not disclosed; retrieved 2026-10-13.

- **[S05]** Chatterji, Cunningham, Deming, Hitzig, Ong, Shan, Wadman / OpenAI and Harvard. [How People Use ChatGPT](https://cdn.openai.com/pdf/a253471f-8260-40c6-a2cc-aa93fe9f142e/economic-research-chatgpt-usage-paper.pdf). 2025-09-15. Measurement period: Consumer classification May 2024-June 2025; aggregate July 2025.

- **[S06]** Huang et al. / Anthropic. [How AI is transforming work at Anthropic](https://www.anthropic.com/research/how-ai-is-transforming-work-at-anthropic). 2025-12-02. Measurement period: Survey August 2025; transcripts February and August 2025.

- **[S07]** Hitzig, Massenkoff, Lyubich, Zhang, Heller, McCrory / Anthropic. [Agentic coding and persistent returns to expertise](https://www.anthropic.com/research/claude-code-expertise). 2026-06-16. Measurement period: October 2025-April 2026.

- **[S08]** Anthropic. [Anthropic Economic Index report: Cadences](https://www.anthropic.com/research/economic-index-june-2026-report). 2026-06-26. Measurement period: Chat/Cowork April 10-June 10, 2026.

- **[S09]** Cursor. [The Cursor Developer Habits Report](https://cursor.com/insights/developer-habits). 2026-07 (landing-page date). Measurement period: Time series 2026-01-01 to 2026-05-09; other windows not fully disclosed.

- **[S10]** Dan Hollick / Cursor. [The asymmetry of token consumption](https://cursor.com/insights/the-asymmetry-of-token-consumption). 2026-09-01. Measurement period: Previous four weeks / 28 days.

- **[S11]** Liu, Qiu, Goiri, Fonseca, Bianchini, Choukse / Microsoft, UIUC. [Agentic Coding in the Wild: Characterizing GitHub Copilot at Production Scale](https://arxiv.org/abs/2608.00101v1). 2026-07-30. Measurement period: First week June 2026.

- **[S12]** Microsoft Azure. [GitHub Copilot Coding Agent Traces 2026 dataset card](https://github.com/Azure/AzurePublicDataset/blob/master/analysis/GitHubCopilotCodingAgents/DATASET_CARD.md). Undated release; retrieved 2026-10-13. Measurement period: 2026-06-01 to 2026-06-07 UTC.

- **[S13]** Sundar Pichai / Google Alphabet. [Alphabet investor presentation: June 2026](https://blog.google/alphabet/investor-presentation-june-2026/). 2026-06-03. Measurement period: March to approximately May/June 2026.

- **[S14]** Mister IA. [Mister IA Panel: usage indicators](https://observatoire.mister-ia.com/en/indicators/). Undated live dashboard. Measurement period: September 2026.

- **[S15]** UK Department for Business and Trade. [The Evaluation of the M365 Copilot Pilot in DBT](https://assets.publishing.service.gov.uk/media/68adbe409e1cebdd2c96a19d/dbt-microsoft-365-copilot-evaluation.pdf). 2025-08-28. Measurement period: 2024-10-01 to 2024-12-30.

- **[S16]** OpenAI. [The State of Enterprise AI 2025](https://openai.com/business/guides-and-resources/the-state-of-enterprise-ai-2025-report/). 2025-12-17. Measurement period: Approximately November 2024-November 2025.

- **[S17]** Marina Favaro, Jack Clark / Anthropic. [When AI builds itself](https://www.anthropic.com/institute/recursive-self-improvement). 2026; updated 2026-09-18. Measurement period: 2025-May 2026; success-rate update September 2026.

- **[S18]** Wen, Qiu, Benton, Kirchner, Leike / Anthropic. [Automated Weak-to-Strong Researcher](https://alignment.anthropic.com/2026/automated-w2s-researcher/). 2026-04 (linked by S17; exact date not exposed). Measurement period: One five-day experiment.

- **[S19]** Anthropic. [Pricing: Claude Platform](https://platform.claude.com/docs/en/about-claude/pricing). Undated live documentation. Measurement period: Snapshot 2026-10-13.

- **[S20]** OpenAI. [Pricing: OpenAI API](https://developers.openai.com/api/docs/pricing). Undated live documentation. Measurement period: Snapshot 2026-10-13.

- **[S21]** OpenAI. [Pricing: ChatGPT Learn / Codex](https://learn.chatgpt.com/docs/pricing). Undated live documentation. Measurement period: Snapshot 2026-10-13.

- **[S22]** Google. [Gemini Apps limits and upgrades](https://support.google.com/gemini/answer/16275805?hl=en). Undated live documentation. Measurement period: Snapshot 2026-10-13.

- **[S23]** Anthropic. [Use Claude Code with your Pro or Max plan](https://support.claude.com/en/articles/11145838-use-claude-code-with-your-pro-or-max-plan). Undated; updated this week. Measurement period: Snapshot 2026-10-13.

- **[S24]** Cottier, Snodin, Owen, Adamczewski / Epoch AI. [LLM inference prices have fallen rapidly but unequally across tasks](https://epoch.ai/data-insights/llm-inference-price-trends). 2025-03-12. Measurement period: Approximately 2022-2025.

- **[S25]** Ara Kharazian / Ramp. [September 2026 Ramp AI Index](https://ramp.com/data/ai-index-sept-2026). 2026-09-09. Measurement period: July and August 2026; price index September 2026.

- **[S26]** Larry Labs. [The only metric that matters in tokenomics](https://research.larrylabs.co/posts/the-only-metric-that-matters-in-tokenomics.html). 2026-09 (day not given). Measurement period: 30 days ending 2026-09-10.

- **[S27]** Chatterji, Holtz, Rakholia, Tambe, Weeratunga / OpenAI. [How Organizations Use AI: Evidence from ChatGPT](https://arxiv.org/abs/2608.12236v1). 2026-08-12; document updated 2026-08-24. Measurement period: Through March 2026.

- **[S28]** Maheux et al. / UNC Chapel Hill and Aura. [How US Youth Use AI Chatbots](https://www.jmir.org/2026/1/e95819). 2026-07-27. Measurement period: Extended observation period; see source.

- **[S29]** Post-Cutoff / Adam Bicz. [Karpathy post archive](https://postcutoff.com/p/2026-10-11-karpathy-capability-gap-funnel/). 2026-10-11. Measurement period: Unofficial archive fetched 2026-10-12.

- **[S30]** Amin Vahdat, Jeff Dean / Google. [How much energy does Google AI use?](https://cloud.google.com/blog/products/infrastructure/measuring-the-environmental-impact-of-ai-inference). 2025-08-21. Measurement period: 2025 production text prompts; see technical paper.

- **[S31]** DeepSeek-AI et al.. [DeepSeek-V3 Technical Report](https://arxiv.org/abs/2412.19437v2). 2024-12-27; revised 2025-02-18. Measurement period: Model architecture.

- **[S32]** Anthropic. [Anthropic Economic Index public dataset](https://huggingface.co/datasets/Anthropic/EconomicIndex). Multiple releases; accessed 2026-10-13. Measurement period: Multiple conversation samples.

- **[S33]** Anthropic. [Measuring AI agent autonomy in practice](https://www.anthropic.com/research/measuring-agent-autonomy). 2026-02-18. Measurement period: Late 2025-early 2026.


- **[S34]** Nicholas Arcolano / Jellyfish. [Is tokenmaxxing cost effective? New data from Jellyfish explains.](https://jellyfish.co/blog/is-tokenmaxxing-cost-effective-new-data-from-jellyfish-explains/). 2026-04-15. Measurement period: Q1 2026.

- **[S35]** Jellyfish Research. [The State of AI in Software Engineering: H1 2026](https://jellyfish.co/state-of-ai-software-engineering/). 2026-06-23 (linked author announcement). Measurement period: August 2025-May 2026; table release snapshots.

- **[S36]** Viberank. [State of AI Coding Spend 2026](https://www.viberank.app/blog/state-of-ai-coding-2026). 2026-06-10. Measurement period: Logged submission windows through June 10, 2026.

- **[S37]** Viberank. [AI coding usage data: Viberank API snapshot](https://www.viberank.app/data). Undated hourly API; frozen 2026-10-13T07:28:30Z. Measurement period: Heterogeneous submission windows, July 2024-October 2026.

- **[S38]** Lisa Bondo Andersen et al. / LMU and MCML. [From Awareness to Action? The Impact of CO2 Emission Feedback on Student LLM Usage](https://doi.org/10.1145/3772363.3798840). 2026-04-13. Measurement period: 2025-07-08 to 2025-07-24 inclusive, as plotted.

- **[S39]** William Small et al. / NYU Langone and Microsoft. [The First Generative AI Prompt-A-Thon in Healthcare](https://journals.plos.org/digitalhealth/article?id=10.1371/journal.pdig.0000394). 2024-07-23. Measurement period: 2023-08-18, 09:00-16:00; two-hour workshop.

- **[S40]** OpenAI. [Enterprise signals: What frontier firms are doing differently](https://openai.com/signals/enterprise-data/). 2026-08-12. Measurement period: January-June 2026; other activity dates not explicit.

- **[S41]** Tomas Pardinas / Jellyfish. [Measuring AI Agent Concurrency](https://jellyfishresearch.substack.com/p/measuring-ai-agent-concurrency). 2026-03-23. Measurement period: Rolling 30-day window; exact dates undisclosed.

- **[S42]** Brad Smith / decost.ai. [Where AI agent tokens go: Claude Code and Codex usage, measured](https://decost.ai/guides/claude-code-codex-token-usage-measured). 2026-09-30 (page label; includes October 1 logs). Measurement period: Claude July 3-October 1; Codex June 4-September 30, 2026.

- **[S43]** Crystal Huang, Joey Brookhart, Dylan Patel / SemiAnalysis. [TokenBudgeting: Our Conversations with Enterprises on Token Spend](https://newsletter.semianalysis.com/p/tokenbudgeting-our-conversations). 2026-06-30. Measurement period: H1 2026 and interviews around Databricks AI Summit.

- **[S44]** Cam Quilici et al. / SemiAnalysis. [AgentX - InferenceXv3: Does CUDA Moat Hold up in Agentic Inferencing?](https://newsletter.semianalysis.com/p/agentx-inferencexv3-does-cuda-moat). 2026-08-24 (live article). Measurement period: Proxy corpus through article snapshot.

- **[S45]** SemiAnalysis. [AgentX Claude Code Weka traces dataset card](https://huggingface.co/datasets/semianalysisai/cc-traces-weka-062126). Dataset built 2026-06-21T17:48:24Z. Measurement period: Selected collected sessions; absolute person-days absent.
